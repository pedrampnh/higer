import { PRODUCTS, type Product } from "./data";

export type AgeKey = "teen" | "young" | "adult" | "senior";
export type PositionKey = "back" | "side" | "stomach" | "combo";
export type PainKey = "none" | "back" | "disc" | "neck" | "joint";
export type SleepersKey = "single" | "coupleCalm" | "coupleMoving";
export type PriorityKey = "ortho" | "cool" | "quiet" | "warranty" | "price" | "soft";

export interface FinderAnswers {
  age: AgeKey | null;
  weight: number;   // kg
  height: number;   // cm
  position: PositionKey | null;
  pain: PainKey | null;
  sleepers: SleepersKey | null;
  firmness: number; // 1 خیلی نرم … 5 خیلی سفت (انتخاب کاربر)
  budget: 1 | 2 | 3 | 4 | null;
  priority: PriorityKey | null;
}

export const DEFAULT_ANSWERS: FinderAnswers = {
  age: null,
  weight: 78,
  height: 172,
  position: null,
  pain: null,
  sleepers: null,
  firmness: 3,
  budget: null,
  priority: null,
};

export const bmiOf = (w: number, h: number) => w / Math.pow(h / 100, 2);

export const bmiStatus = (bmi: number): { label: string; tone: "ok" | "warn" | "high" | "low" } => {
  if (bmi < 18.5) return { label: "کمبود وزن", tone: "low" };
  if (bmi < 25) return { label: "وزن نرمال", tone: "ok" };
  if (bmi < 30) return { label: "اضافه‌وزن", tone: "warn" };
  return { label: "چاقی", tone: "high" };
};

export const budgetBand = (price: number): 1 | 2 | 3 | 4 =>
  price <= 30_000_000 ? 1 : price <= 60_000_000 ? 2 : price <= 150_000_000 ? 3 : 4;

export interface ScoredProduct {
  product: Product;
  pct: number;             // درصد تطبیق ۶۲..۹۹
  reasons: string[];       // دلایل اختصاصی
  firmnessShown: number;   // سفتی توضیح‌داده‌شده
}

const clamp = (v: number, a = 1, b = 5) => Math.min(b, Math.max(a, v));

/** سفتی ایده‌آل را از ترکیب انتخاب کاربر + علم ارگونومی محاسبه می‌کند */
export function desiredFirmness(a: FinderAnswers): number {
  let d = a.firmness;
  if (a.weight > 100) d += 0.7;
  else if (a.weight < 55) d -= 0.7;
  if (a.position === "stomach") d += 0.6;
  else if (a.position === "side") d -= 0.6;
  else if (a.position === "back") d += 0.2;
  if (a.pain && a.pain !== "none") d += a.pain === "joint" ? 0.1 : 0.5;
  if (a.age === "teen") d += 0.3;
  else if (a.age === "senior") d -= 0.2;
  return clamp(d);
}

function scoreOne(p: Product, a: FinderAnswers): number {
  const desired = desiredFirmness(a);

  /* ۱) تطابق سفتی — وزن ۰٫۳۰ */
  const firmScore = clamp(1 - Math.abs(p.firm - desired) / 2.3, 0, 1);

  /* ۲) حمایت لازم از ستون فقرات — وزن ۰٫۲۲ */
  const need = clamp(
    3 + (a.weight > 95 ? 1 : a.weight < 55 ? -1 : 0) + (a.pain && a.pain !== "none" ? 1 : 0) + (a.age === "teen" ? 0.5 : 0),
  );
  const supportScore = clamp(1 - Math.abs(p.support - need) / 2.6, 0, 1);

  /* ۳) ایزولاسیون حرکت — وزن ۰٫۱۶ */
  let motionScore: number;
  if (a.sleepers === "coupleMoving") motionScore = p.motion / 5;
  else if (a.sleepers === "coupleCalm") motionScore = 0.65 + 0.35 * (p.motion / 5);
  else motionScore = 0.8 + 0.2 * (p.motion / 5);

  /* ۴) سطح ارتوپدیک برای درد — وزن ۰٫۱۶ */
  let orthoScore = 1;
  if (a.pain && a.pain !== "none") {
    orthoScore = p.ortho / 5;
    if ((a.pain === "disc" || a.pain === "back") && p.core === "rebond") orthoScore = clamp(orthoScore + 0.12);
    if (a.pain === "disc" && p.core === "bonnell") orthoScore -= 0.15;
  }

  /* ۵) تناسب بودجه — وزن ۰٫۱۲ */
  const band = a.budget ?? 2;
  const pb = budgetBand(p.startPrice);
  const diff = pb - band;
  const budgetScore = diff === 0 ? 1 : diff < 0 ? 0.92 + diff * 0.05 : diff === 1 ? 0.32 : 0.06;

  /* ۶) وزن بدن در بازه ایده‌آل مدل */
  const inRange = a.weight >= p.idealMin && a.weight <= p.idealMax;
  const weightBonus = inRange ? 0.05 : -0.09;

  /* امتیاز پایه وزندار (ماکزیمم ≈ ۰٫۹۶) */
  let s =
    firmScore * 0.30 +
    supportScore * 0.22 +
    motionScore * 0.16 +
    orthoScore * 0.16 +
    clamp(budgetScore, 0, 1) * 0.12 +
    weightBonus;

  /* ۷) اولویت اصلی — تا +۰٫۰۸ */
  if (a.priority === "ortho") s += (p.ortho / 5) * 0.08;
  else if (a.priority === "cool") s += (p.cooling / 5) * 0.08;
  else if (a.priority === "quiet") s += (p.motion / 5) * 0.08;
  else if (a.priority === "warranty") s += (p.warranty / 10) * 0.08;
  else if (a.priority === "price") s += budgetBand(p.startPrice) <= band ? 0.08 : 0.02;
  else if (a.priority === "soft") s += ((6 - p.firm) / 5) * 0.08;

  /* هماهنگی پوزِیشن خواب */
  if (a.position && p.positions.includes(a.position)) s += 0.03;

  /* نرمال‌سازی به بازه ۶۲..۹۹ */
  const norm = clamp(s / 1.08, 0, 1);
  return Math.round(62 + norm * 37);
}

const painFa: Record<PainKey, string> = {
  none: "بدون مشکل جسمی خاص",
  back: "کمردرد",
  disc: "دیسک و مهره‌های کمر",
  neck: "گردن و شانه",
  joint: "مفصل و زانو",
};

const positionFa: Record<PositionKey, string> = {
  back: "خواب پشت",
  side: "خواب پهلو",
  stomach: "خواب روی شکم",
  combo: "خواب ترکیبی",
};

export function analyze(a: FinderAnswers): ScoredProduct[] {
  const desired = desiredFirmness(a);
  const bmi = bmiOf(a.weight, a.height);

  const scored = PRODUCTS.map((p) => ({
    product: p,
    pct: scoreOne(p, a),
    firmnessShown: desired,
    reasons: buildReasons(p, a, bmi),
  })).sort((x, y) => y.pct - x.pct);

  /* تنوع دسته‌بندی: اگر ۳ تای اول از یک هسته باشند، سومی را با متنوع‌ترین تعویض کن */
  const top = scored.slice(0, 3);
  const cores = new Set(top.map((t) => t.product.core));
  if (cores.size < 2) {
    const alt = scored.find(
      (s) => !top.slice(0, 2).some((t) => t.product.id === s.product.id) && s.product.core !== top[0].product.core,
    );
    if (alt && top[2].pct - alt.pct <= 8) top[2] = alt;
  }
  return top;
}

function buildReasons(p: Product, a: FinderAnswers, bmi: number): string[] {
  const r: string[] = [];
  r.push(
    `برای وزن ${Math.round(a.weight)} کیلوگرم و قد ${Math.round(a.height)} سانتی‌متر (BMI ≈ ${bmi.toFixed(1)})، حمایت سطح ${p.support}/۵ این مدل همسو است.`,
  );
  if (a.pain && a.pain !== "none") {
    r.push(
      p.ortho >= 4
        ? `به دلیل «${painFa[a.pain]}»، هسته ${p.core === "rebond" ? "ریباند ارتوپدیک" : "فوم سنگین چگال"} با سطح ارتوپدیک ${p.ortho}/۵ پیشنهاد شد.`
        : `برای «${painFa[a.pain]}»، لایه آسایش و سفتی ${p.firm} از ${p.firm >= 4 ? "بالا" : "متوسط"} فشار را از روی مهره‌ها برمی‌دارد.`,
    );
  } else {
    r.push(`«${positionFa[a.position ?? "combo"]}» شما با پروفایل سفتی ${p.firm} از ۵ این مدل هماهنگ است.`);
  }
  if (a.sleepers === "coupleMoving") {
    r.push(
      p.motion >= 4
        ? "خواب دو‌نفره پرتحرک: انتقال حرکت در این هسته تقریباً صفر است؛ بیداری شبانه همسرتان حذف می‌شود."
        : "برای خواب دونفره، لایه بافر این مدل لرزش‌ها را تا حد قابل‌قبولی مهار می‌کند.",
    );
  } else if (a.sleepers === "coupleCalm") {
    r.push("خواب دونفره آرام: تعادل سفتی و آسایش بدون صدای فنر.");
  } else {
    r.push("خواب تک‌نفره: آزادی کامل سلیقه در انتخاب حس و سفتی.");
  }
  return r.slice(0, 3);
}
