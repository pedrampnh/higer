/* نسخه قابل‌جاسازی صفحه هوم هیگر برای وردپرس (WPCode / المنتور).
   همان اپلیکیشن پیش‌نمایش داخل Shadow DOM اجرا می‌شود تا استایل قالب سایت و صفحه روی هم اثر نگذارند. */
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import cssText from "./index.css?inline";
import App from "./App";
import { config } from "./embed-config";

const FONT_LINKS = [
  "https://cdn.jsdelivr.net/gh/saraf-io/iransans-font@master/font-face.css",
  "https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css",
];

/** rem به px — تا اندازه‌ها به font-size قالب سایت وابسته نباشند */
const remToPx = (css: string) =>
  css.replace(/(-?\d*\.?\d+)rem\b/g, (_m, n: string) => `${Number((parseFloat(n) * 16).toFixed(4))}px`);

const PROPERTY_RULES = (cssText.match(/@property\s+--[\w-]+\s*\{[^}]*\}/g) || []).join("\n");

const HOST_CSS = `
:host { all: initial; display: block; }
.hg-root {
  font-family: "IRANSans", "Vazirmatn", "Segoe UI", Tahoma, sans-serif;
  color: #10243e; background: #faf7ef; direction: rtl; text-align: right;
  font-size: 16px; line-height: 1.5; -webkit-font-smoothing: antialiased; text-rendering: optimizeLegibility;
}
[id] { scroll-margin-top: 110px; }
`;

const SHADOW_CSS = remToPx(cssText) + HOST_CSS;

function ensureDocumentAssets() {
  const head = document.head || document.documentElement;
  for (const href of FONT_LINKS) {
    if (!document.querySelector(`link[href="${href}"]`)) {
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = href;
      head.appendChild(link);
    }
  }
  /* @property داخل Shadow DOM کار نمی‌کند؛ باید در سطح سند ثبت شود */
  if (PROPERTY_RULES && !document.getElementById("higer-home-props")) {
    const style = document.createElement("style");
    style.id = "higer-home-props";
    style.textContent = PROPERTY_RULES;
    head.appendChild(style);
  }
}

/** صفحه را تمام‌عرض می‌کند، حتی اگر داخل یک ستون محدود المنتور باشد */
function makeFullWidth(host: HTMLElement) {
  const fit = () => {
    host.style.position = "relative";
    host.style.maxWidth = "none";
    host.style.left = "0px";
    const width = document.documentElement.clientWidth;
    host.style.width = `${width}px`;
    const rect = host.getBoundingClientRect();
    host.style.left = `${-rect.left}px`;
  };
  fit();
  window.addEventListener("resize", fit);
  window.addEventListener("load", fit);
  window.setTimeout(fit, 600);
}

function mount(host: HTMLElement) {
  if (host.dataset.higerMounted) return;
  host.dataset.higerMounted = "1";
  const ds = host.dataset;
  config.embed = true;
  config.header = ds.header === "yes";
  config.footer = ds.footer !== "no";
  config.only = ds.only === "finder" ? "finder" : "";

  const shadow = host.shadowRoot ?? host.attachShadow({ mode: "open" });
  config.root = shadow;
  shadow.innerHTML = "";
  const style = document.createElement("style");
  style.textContent = SHADOW_CSS;
  shadow.appendChild(style);
  const container = document.createElement("div");
  container.className = "hg-root";
  container.dir = "rtl";
  container.lang = "fa";
  shadow.appendChild(container);

  /* لینک‌های # داخل Shadow DOM را مرورگر پیدا نمی‌کند؛ خودمان پیمایش می‌کنیم */
  shadow.addEventListener("click", (event) => {
    const anchor = event
      .composedPath()
      .find((n): n is HTMLAnchorElement => n instanceof HTMLAnchorElement && (n.getAttribute("href") || "").startsWith("#"));
    if (!anchor) return;
    const id = (anchor.getAttribute("href") || "").slice(1);
    const target = id ? shadow.getElementById(id) : null;
    event.preventDefault();
    (target ?? host).scrollIntoView({ behavior: "smooth", block: "start" });
  });

  if (ds.fullwidth !== "no" && config.only !== "finder") makeFullWidth(host);
  host.style.minHeight = "";
  host.style.background = "";

  createRoot(container).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}

function mountAll() {
  ensureDocumentAssets();
  document.querySelectorAll<HTMLElement>("[data-higer-home]").forEach(mount);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", mountAll);
} else {
  mountAll();
}
