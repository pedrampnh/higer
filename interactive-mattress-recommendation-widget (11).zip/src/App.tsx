import { useCallback, useEffect, useState } from "react";
import { Phone, ArrowUp } from "lucide-react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Finder from "./components/Finder";
import Categories from "./components/Categories";
import Products, { type CoreFilter } from "./components/Products";
import Accessories from "./components/Accessories";
import Extras from "./components/Extras";
import WidgetSection from "./components/WidgetSection";
import Footer from "./components/Footer";
import { STORE, type CoreKey } from "./data";
import { config, scrollToId } from "./embed-config";

export default function App() {
  const [filter, setFilter] = useState<CoreFilter>("all");
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 480);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleCoreSelect = useCallback((core: CoreKey) => {
    setFilter(core);
    scrollToId("products");
  }, []);

  return (
    <div className={`${config.embed ? "" : "min-h-screen "}bg-hg-cream text-hg-navy-900`} id="page-top">
      {config.header && config.only !== "finder" && <Header />}
      <main>
        {config.only === "finder" ? (
          <Finder />
        ) : (
          <>
            <Hero />
            <Finder />
            <Categories onSelect={handleCoreSelect} />
            <Products selected={filter} onChange={setFilter} />
            <Accessories />
            <Extras />
            {!config.embed && <WidgetSection />}
          </>
        )}
      </main>
      {config.footer && config.only !== "finder" && <Footer />}

      {/* ===== دکمه‌های شناور ===== */}
      {config.only !== "finder" && <div className="fixed bottom-5 left-4 z-50 flex flex-col items-center gap-2 sm:left-6">
        {showTop && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            aria-label="بازگشت به بالا"
            className="grid h-12 w-12 place-items-center rounded-2xl border border-hg-line bg-white/90 text-hg-navy-900 shadow-lg backdrop-blur transition hover:bg-white"
          >
            <ArrowUp size={20} />
          </button>
        )}
        <a
          href={STORE.telHref}
          aria-label="تماس با مشاور هیگر"
          className="group grid h-16 w-16 place-items-center rounded-2xl bg-hg-gold-500 text-hg-navy-900 shadow-[0_14px_34px_rgba(217,161,59,0.45)] transition hover:scale-105"
        >
          <Phone size={26} strokeWidth={2.2} className="transition group-hover:rotate-12" />
          <span className="absolute -right-2 -top-2 grid h-6 w-6 place-items-center rounded-full border-2 border-hg-cream bg-emerald-500">
            <span className="h-2 w-2 animate-ping rounded-full bg-white" />
          </span>
        </a>
      </div>}
    </div>
  );
}
