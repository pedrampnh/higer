/* تنظیمات اجرای صفحه — در پیش‌نمایش مقادیر پیش‌فرض، در اسنیپت وردپرس توسط embed.tsx پر می‌شوند */

export type AssetKey = "hero" | "factory" | "topper";

declare global {
  interface Window {
    HIGER_ASSETS?: Partial<Record<AssetKey, string>>;
  }
}

export interface EmbedConfig {
  embed: boolean;
  header: boolean;
  footer: boolean;
  only: "" | "finder";
  root: Document | ShadowRoot;
}

export const config: EmbedConfig = {
  embed: false,
  header: true,
  footer: true,
  only: "",
  root: document,
};

const DEFAULT_ASSETS: Record<AssetKey, string> = {
  hero: "/images/hero-bg.webp",
  factory: "/images/factory.jpg",
  topper: "/images/topper.jpg",
};

/** آدرس عکس؛ رشته خالی یعنی عکسی پیدا نشد */
export function asset(key: AssetKey): string {
  const custom = typeof window !== "undefined" ? window.HIGER_ASSETS?.[key] : undefined;
  return custom === undefined || custom === null ? DEFAULT_ASSETS[key] : String(custom);
}

/** پیمایش به یک بخش، هم در صفحه عادی و هم داخل Shadow DOM */
export function scrollToId(id: string) {
  const el = config.root.getElementById(id) ?? document.getElementById(id);
  el?.scrollIntoView({ behavior: "smooth", block: "start" });
}
