import { useState } from "react";
import {
  BedSingle, ShieldCheck, Droplets, Wind, Feather, Bug, Baby, Check,
  ExternalLink, Layers3, Ruler, Shirt, ChevronDown, PackageCheck, HeartPulse,
} from "lucide-react";
import { faPrice } from "../utils/fa";
import { STORE } from "../data";
import { asset } from "../embed-config";

const SIZES = ["۸۰×۱۸۰", "۹۰×۲۰۰", "۱۰۰×۲۰۰", "۱۲۰×۲۰۰", "۱۴۰×۲۰۰", "۱۶۰×۲۰۰", "۱۸۰×۲۰۰", "۲۰۰×۲۰۰"];

const TOPPER_URL = "https://higermattress.ir/?s=%D8%AA%D8%A7%D9%BE%D8%B1&post_type=product";
const PROTECTOR_URL = "https://higermattress.ir/?s=%D9%85%D8%AD%D8%A7%D9%81%D8%B8%20%D8%AA%D8%B4%DA%A9&post_type=product";

const TOPPER_FEATURES = [
  { icon: Feather, text: "تشک فعلی‌تان سفت است؟ تاپر ۵–۸ سانتی متری آن را به سطح هتلینگ نرم تبدیل می‌کند." },
  { icon: HeartPulse, text: "تماس نقطه‌ای شانه و لگن را کاهش می‌دهد؛ گزینه عالی برای خواب پهلو و دیسک." },
  { icon: Layers3, text: "لایه واحدِ قابل تعویض؛ بدون عوض کردن کل تشک، حس تخت نو را بخرید." },
  { icon: Wind, text: "نسخه‌های تهویه‌دار با جریان هوا، گرمای فوم و الیاف را دفع می‌کنند." },
];

const PROTECTOR_FEATURES = [
  { icon: Droplets, text: "ضدآب ۱۰۰٪ — محافظ کامل تشک در برابر عرق، مایعات، شب‌اداری کودک و لک." },
  { icon: Bug, text: "بافت ضدکنه و آنتی‌باکتریال؛ دشمن آلرژی فصلی و آسم." },
  { icon: Shirt, text: "قابل شستشو در ماشین لباسشویی؛ فقط کش‌ها را بگیرید، باقی خودش فیکس می‌شود." },
  { icon: ShieldCheck, text: "عمر مفید تشک را تا ۲ برابر افزایش می‌دهد و گارانتی را دست‌نخورده نگه می‌دارد." },
];

const GUIDE = [
  { q: "تاپر چه ضخامتی بخرم؟", a: "برای نرم کردن تشک سفت، ۵ تا ۸ سانتی‌متر؛ برای افزایش عمر و لطافت ملایم، ۳ تا ۵ سانتی‌متر کافی است. ضخامت بالاتر همیشه بهتر نیست — وزن بالاتر، فرورفتگی عمیق‌تر." },
  { q: "محافظ تشک صدا دارد؟", a: "خیر؛ لایه ضدآب هیگر از پلی‌اورتان تنفس‌پذیر ساخته شده نه نایلون قدیمی، پس هیچ صدای خش‌خشی ندارد و هوا از آن عبور می‌کند." },
  { q: "تاپر و محافظ را با هم بخرم؟", a: "بله — ترتیب درست روی تخت: تشک → محافظ ضدآب (مستقیم روی تشک) → تاپر. محافظ از تشک و تاپر از هر دو محافظت می‌کند." },
];

export default function Accessories() {
  const [openGuide, setOpenGuide] = useState(0);

  return (
    <section id="accessories" className="paper-texture border-t border-hg-line py-16 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* ===== سربرگ ===== */}
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-2xl">
            <p className="inline-flex items-center gap-2 rounded-full border border-hg-gold-500/50 bg-white/70 px-4 py-1.5 text-[10px] font-bold text-hg-gold-600">
              <PackageCheck size={12} /> محصولات جانبی هیگر
            </p>
            <h2 className="mt-4 text-3xl font-black leading-snug text-hg-navy-900 sm:text-4xl">
              تاپر و محافظ تشک؛ <span className="gold-text">نیمه‌ی گمشده تشک شما</span>
            </h2>
            <p className="mt-3 text-sm leading-8 text-hg-navy-700">
              تاپر تشک فعلی‌تان را بدون تعویض، به نسل جدید تبدیل می‌کند و محافظ ضدآب، سرمایه‌تان را در برابر عرق و لک بیمه می‌کند.
              هر دو در ۸ سایز استاندارد — همان سایزهای تشک‌های هیگر.
            </p>
          </div>
          <a href={TOPPER_URL} target="_blank" rel="noopener noreferrer"
            className="group inline-flex items-center gap-2 rounded-full bg-hg-navy-900 px-5 py-3 text-xs font-black text-hg-gold-300 transition hover:bg-hg-navy-800">
            دیدن تاپرها در فروشگاه
            <ExternalLink size={14} className="transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </a>
        </div>

        {/* ===== گرید اصلی ===== */}
        <div className="mt-10 grid gap-6 lg:grid-cols-12">
          {/* تصویر */}
          <figure className="relative overflow-hidden rounded-3xl border border-hg-line shadow-[0_24px_55px_rgba(16,36,62,0.22)] lg:col-span-4">
            {asset("topper") ? (
              <img src={asset("topper")} alt="تاپر و محافظ تشک هیگر روی تخت سرمه‌ای" loading="lazy" className="h-full min-h-[280px] w-full object-cover" />
            ) : (
              <div aria-hidden="true" className="midnight grid-lines h-full min-h-[280px] w-full" />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-hg-navy-950/85 via-hg-navy-950/15 to-transparent" aria-hidden="true" />
            <figcaption className="absolute bottom-4 right-4 left-4">
              <p className="text-[10px] font-bold tracking-widest text-hg-gold-400">HIGER ACCESSORIES</p>
              <p className="mt-0.5 text-sm font-black text-white">تشک + محافظ + تاپر = خواب کامل</p>
            </figcaption>
          </figure>

          {/* کارت تاپر */}
          <article className="light-card flex flex-col rounded-3xl p-6 lg:col-span-4">
            <div className="flex items-center justify-between gap-3">
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-hg-navy-900 text-hg-gold-400">
                <BedSingle size={28} strokeWidth={1.8} />
              </span>
              <div className="text-left">
                <p className="text-[8px] font-bold text-hg-navy-600">محدوده قیمت فروشگاه</p>
                <p className="text-xs font-black text-hg-navy-900" dir="ltr">{faPrice(13_000_000)} – {faPrice(30_000_000)}</p>
              </div>
            </div>
            <h3 className="mt-4 text-2xl font-black text-hg-navy-900">تاپر <span className="gold-text">Topper</span></h3>
            <p className="mt-1 text-[10px] font-bold text-hg-navy-600">«تشک روی تشک» — ارتقای حس خواب بدون تعویض تشک</p>
            <ul className="mt-4 mb-5 space-y-2.5">
              {TOPPER_FEATURES.map(({ icon: Icon, text }, i) => (
                <li key={i} className="flex items-start gap-2 text-[10px] leading-6 text-hg-navy-800">
                  <Icon size={14} strokeWidth={2} className="mt-1 shrink-0 text-hg-gold-600" />
                  {text}
                </li>
              ))}
            </ul>
            <a href={TOPPER_URL} target="_blank" rel="noopener noreferrer"
              className="mt-auto inline-flex items-center justify-center gap-2 rounded-2xl border-2 border-hg-navy-900 bg-hg-navy-900 px-5 py-3.5 text-[11px] font-black text-hg-gold-300 transition hover:bg-hg-navy-800 focus:outline-none focus:ring-2 focus:ring-hg-gold-500">
              انتخاب سایز و خرید تاپر <ExternalLink size={13} />
            </a>
          </article>

          {/* کارت محافظ تشک */}
          <article className="light-card flex flex-col rounded-3xl p-6 lg:col-span-4">
            <div className="flex items-center justify-between gap-3">
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-hg-gold-500 text-hg-navy-900">
                <Droplets size={28} strokeWidth={1.8} />
              </span>
              <div className="text-left">
                <p className="text-[8px] font-bold text-hg-navy-600">محدوده قیمت فروشگاه</p>
                <p className="text-xs font-black text-hg-navy-900" dir="ltr">{faPrice(3_300_000)} – {faPrice(8_200_000)}</p>
              </div>
            </div>
            <h3 className="mt-4 text-2xl font-black text-hg-navy-900">محافظ تشک <span className="gold-text">ضدآب</span></h3>
            <p className="mt-1 text-[10px] font-bold text-hg-navy-600">زره نامرئی تشک — عرق، لک و کنه به آن نمی‌رسد</p>
            <ul className="mt-4 mb-5 space-y-2.5">
              {PROTECTOR_FEATURES.map(({ icon: Icon, text }, i) => (
                <li key={i} className="flex items-start gap-2 text-[10px] leading-6 text-hg-navy-800">
                  <Icon size={14} strokeWidth={2} className="mt-1 shrink-0 text-hg-navy-700" />
                  {text}
                </li>
              ))}
            </ul>
            <a href={PROTECTOR_URL} target="_blank" rel="noopener noreferrer"
              className="mt-auto inline-flex items-center justify-center gap-2 rounded-2xl border-2 border-hg-gold-500 bg-hg-gold-500 px-5 py-3.5 text-[11px] font-black text-hg-navy-900 transition hover:bg-hg-gold-400 focus:outline-none focus:ring-2 focus:ring-hg-gold-600">
              انتخاب سایز و خرید محافظ <ExternalLink size={13} />
            </a>
          </article>
        </div>

        {/* ===== سایزها ===== */}
        <div className="mt-6 flex flex-col gap-3 rounded-2xl border border-hg-line bg-white p-4 sm:flex-row sm:items-center">
          <span className="flex shrink-0 items-center gap-2 text-[11px] font-black text-hg-navy-900">
            <Ruler size={15} className="text-hg-gold-600" /> هر دو محصول در ۸ سایز استاندارد:
          </span>
          <div className="flex flex-wrap gap-1.5" dir="rtl">
            {SIZES.map((s) => (
              <span key={s} className="rounded-lg border border-hg-line bg-hg-cream px-2.5 py-1 text-[10px] font-bold text-hg-navy-800">{s}</span>
            ))}
          </div>
          <span className="flex shrink-0 items-center gap-1.5 text-[9px] font-bold text-emerald-700">
            <Check size={12} strokeWidth={3.5} /> کشِ دور تا دور — فیکس بدون لغزش
          </span>
        </div>

        {/* ===== راهنمای سریع ===== */}
        <div className="mt-6 grid gap-4 lg:grid-cols-12">
          <div className="rounded-2xl bg-hg-navy-900 p-5 text-hg-cream lg:col-span-4">
            <Baby size={26} className="text-hg-gold-400" strokeWidth={1.8} />
            <h3 className="mt-3 text-base font-black">به درد چه‌کسانی می‌خورد؟</h3>
            <ul className="mt-3 space-y-2 text-[10px] leading-6 text-hg-cream/85">
              <li className="flex items-start gap-2"><Check size={12} strokeWidth={3.5} className="mt-1 shrink-0 text-hg-gold-400" />والدین نوزاد و کودک — مقابل شب‌اداری و لک شیر</li>
              <li className="flex items-start gap-2"><Check size={12} strokeWidth={3.5} className="mt-1 shrink-0 text-hg-gold-400" />مبتلایان به آلرژی، آسم و سینوزیت</li>
              <li className="flex items-start gap-2"><Check size={12} strokeWidth={3.5} className="mt-1 shrink-0 text-hg-gold-400" />تخت‌های اجاره‌ای، سوئیت مهمان و ویلاها</li>
              <li className="flex items-start gap-2"><Check size={12} strokeWidth={3.5} className="mt-1 shrink-0 text-hg-gold-400" />تشک تازه‌خرید هنوز که «عادت کردن» نشده است</li>
            </ul>
            <a href="tel:+989116406485" className="mt-4 flex items-center justify-center gap-2 rounded-xl border border-hg-gold-500/40 bg-hg-gold-500/10 py-2.5 text-[10px] font-black text-hg-gold-300 transition hover:bg-hg-gold-500/20" style={{ direction: "ltr" }}>
              مشاوره انتخاب سایز: {STORE.phone}
            </a>
          </div>
          <div className="lg:col-span-8">
            <div className="divide-y divide-hg-line overflow-hidden rounded-2xl border border-hg-line bg-white">
              {GUIDE.map((item, i) => {
                const isOpen = openGuide === i;
                return (
                  <div key={i}>
                    <button onClick={() => setOpenGuide(isOpen ? -1 : i)} aria-expanded={isOpen}
                      className="flex w-full items-center justify-between gap-4 px-5 py-4 text-right transition hover:bg-hg-cream/60">
                      <span className="text-[11px] font-black text-hg-navy-900">{item.q}</span>
                      <ChevronDown size={17} className={`shrink-0 text-hg-gold-600 transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`} />
                    </button>
                    {isOpen && <p className="fade-up px-5 pb-4 text-[10px] leading-7 text-hg-navy-700">{item.a}</p>}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
