import { useState } from "react";
import { Phone, MapPin, Clock, Send, CheckCircle2, AtSign } from "lucide-react";
import Logo from "./Logo";
import { STORE } from "../data";
import { config } from "../embed-config";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  const subscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return;
    setDone(true);
  };

  return (
    <footer className="midnight text-hg-cream">
      <div className="mx-auto max-w-7xl px-4 pb-8 pt-14 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-12">
          {/* برند */}
          <div className="lg:col-span-3">
            <Logo dark={false} />
            <p className="mt-4 text-[11px] leading-6 text-hg-cream/70">
              تولید تخصصی تشک از سال {STORE.est}؛ ۲۷ مدل در ۴ هسته اصلی — فنر متصل، فنر منفصل، ریباند و فوم سنگین —
              با گارانتی شرکتی ۵ تا ۱۰ ساله و ارسال مستقیم از کارخانه.
            </p>
            <div className="mt-5 flex items-center gap-3">
              {[AtSign, Send].map((Icon, i) => (
                <a key={i} href="https://higermattress.ir" target="_blank" rel="noopener noreferrer" aria-label={i === 0 ? "اینستاگرام هیگر" : "تلگرام هیگر"}
                  className="grid h-10 w-10 place-items-center rounded-xl border border-white/15 bg-white/5 text-hg-gold-300 transition hover:border-hg-gold-500/50 hover:bg-hg-gold-500/15">
                  <Icon size={18} strokeWidth={1.8} />
                </a>
              ))}
              {/* نماد اعتماد تقریبی */}
              <span className="flex items-center gap-2 rounded-xl border border-hg-gold-500/40 bg-hg-gold-500/10 px-3 py-2">
                <svg width="26" height="26" viewBox="0 0 26 26" aria-hidden="true">
                  <path d="M13 1l10 4v7c0 6.5-4.2 11-10 13C7.2 23 3 18.5 3 12V5l10-4z" fill="none" stroke="#d9a13b" strokeWidth="1.6" />
                  <path d="M9 13.2l2.8 2.8L17.4 10" fill="none" stroke="#d9a13b" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span className="text-[8px] font-bold leading-4 text-hg-gold-200">نماد اعتماد<br />و گارانتی شرکتی</span>
              </span>
            </div>
          </div>

          {/* دسترسی سریع */}
          <nav className="lg:col-span-2" aria-label="دسترسی سریع">
            <p className="text-[10px] font-black tracking-widest text-hg-gold-400">دسترسی سریع</p>
            <ul className="mt-3 space-y-2 text-[11px] font-bold text-hg-cream/80">
              {[
                ["تشک‌سنج هوشمند", "#tashik-sanj"],
                ["۴ هسته اصلی", "#hast-ha"],
                ["محصولات فروشگاه", "#products"],
                ["تاپر و محافظ تشک", "#accessories"],
                ["سوالات متداول", "#faq"],
                ...(config.embed ? [] : [["نصب ویجت روی سایت", "#widget"]]),
                ["فروشگاه آنلاین", "https://higermattress.ir/shop/"],
              ].map(([label, href]) => (
                <li key={href as string}><a href={href as string} className="transition hover:text-hg-gold-300">{label as string}</a></li>
              ))}
            </ul>
          </nav>

          {/* دسته‌بندی هسته‌ها */}
          <nav className="lg:col-span-2" aria-label="هسته‌های تشک">
            <p className="text-[10px] font-black tracking-widest text-hg-gold-400">هسته‌های تشک</p>
            <ul className="mt-3 space-y-2 text-[11px] font-bold text-hg-cream/80">
              {[
                "فنر متصل (بونل)",
                "فنر منفصل (پاکتی)",
                "ریباند ارتوپدیک",
                "فوم سنگین طبی",
                "تاپر و محافظ تشک",
                "تشک مهمانی",
              ].map((t, i) => (
                <li key={t}><a href={i === 4 ? "#accessories" : "#hast-ha"} className="transition hover:text-hg-gold-300">{t}</a></li>
              ))}
            </ul>
          </nav>

          {/* تماس */}
          <div className="lg:col-span-2">
            <p className="text-[10px] font-black tracking-widest text-hg-gold-400">تماس</p>
            <ul className="mt-3 space-y-3 text-[10px] leading-5 text-hg-cream/80">
              <li className="flex items-start gap-2"><Phone size={13} className="mt-0.5 shrink-0 text-hg-gold-400" /><a href={STORE.telHref} dir="ltr" className="font-black text-hg-gold-300 hover:text-white">{STORE.phone}</a></li>
              <li className="flex items-start gap-2"><MapPin size={13} className="mt-0.5 shrink-0 text-hg-gold-400" />{STORE.address}</li>
              <li className="flex items-start gap-2"><Clock size={13} className="mt-0.5 shrink-0 text-hg-gold-400" />پاسخگویی: {STORE.hours}</li>
            </ul>
          </div>

          {/* خبرنامه */}
          <div className="lg:col-span-3">
            <p className="text-[10px] font-black tracking-widest text-hg-gold-400">جشنواره‌ها و تخفیف‌ها</p>
            <p className="mt-2 text-[10px] leading-5 text-hg-cream/70">ایمیل‌تان را بگذارید؛ از جشنواره‌های فصلی و کدهای تخفیف اختصاصی جا نمانید.</p>
            {done ? (
              <p className="fade-up mt-3 flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-3 text-[11px] font-bold text-emerald-300">
                <CheckCircle2 size={16} /> ثبت شد! منتظر جشنواره بعدی هیگر باشید.
              </p>
            ) : (
              <form onSubmit={subscribe} className="mt-3 flex overflow-hidden rounded-xl border border-white/15 bg-white/5 focus-within:border-hg-gold-500/60">
                <label className="sr-only" htmlFor="hg-newsletter">ایمیل شما</label>
                <input id="hg-newsletter" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" dir="ltr"
                  className="w-full bg-transparent px-4 py-3 text-[11px] text-white outline-none placeholder:text-white/35" />
                <button type="submit" aria-label="عضویت در خبرنامه" className="grid w-14 shrink-0 place-items-center bg-hg-gold-500 text-hg-navy-900 transition hover:bg-hg-gold-400">
                  <Send size={17} strokeWidth={2.4} className="-scale-x-100" />
                </button>
              </form>
            )}
          </div>
        </div>

        {/* ردیف پایین */}
        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-5 text-[9px] text-hg-cream/55 sm:flex-row">
          <p>© {new Date().getFullYear() === 2026 ? "۱۴۰۴–۱۴۰۵" : "۱۴۰۵"} شرکت تشک هیگر | کلیه حقوق محفوظ است.</p>
          <div className="flex items-center gap-4">
            <a href="https://higermattress.ir/قوانین-و-مقررات/" className="transition hover:text-hg-gold-300">قوانین و مقررات</a>
            <a href="https://higermattress.ir/ضمانت-تشک-ها/" className="transition hover:text-hg-gold-300">شرایط گارانتی</a>
            <a href="https://higermattress.ir/" className="transition hover:text-hg-gold-300">higermattress.ir</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
