import { useState } from "react";
import { Factory, ShieldCheck, Truck, ChevronDown, Award, Leaf, HeartHandshake } from "lucide-react";
import { toFa } from "../utils/fa";
import { asset } from "../embed-config";

const ADVANTAGES = [
  { icon: Factory, title: "تولید ۱۰۰٪ ملی از ۱۳۸۷", text: "از برش فولاد تا دوخت گردباف؛ تمام مراحل در کارخانه هیگر انجام و کنترل می‌شود." },
  { icon: ShieldCheck, title: "گارانتی شرکتی تعویض", text: "۵ تا ۱۰ سال گارانتی تعویض کتبی؛ با هولوگرام و کارت گارانتی داخل بسته‌بندی." },
  { icon: Truck, title: "ارسال و نصب رایگان", text: "حمل تا اتاق خواب، بازکردن و نصب توسط تیم هیگر — حتی طبقات بدون آسانسور." },
  { icon: Leaf, title: "پارچه ضدحساسیت", text: "گردباف آنتی‌باکتریال با الیاف ضدکنه؛ مناسب کودک و بیماران تنفسی." },
  { icon: Award, title: "استانداردهای روز جهانی", text: "الهام از برندهای مطرح اروپا؛ تست ۱۰۰٬۰۰۰ سیکل فشار و غلتک روی هر لات تولید." },
  { icon: HeartHandshake, title: "۳۶۵ روز بازخورد", text: "اگر در سال اول از انتخاب‌تان راضی نبودید، مشاور تعویض مدل در اختیارتان است." },
];

const FAQS = [
  { q: "فنر متصل بهتر است یا فنر منفصل؟", a: "فنر متصل (بونل) سفت، یکنواخت و اقتصادی است و برای خواب پشت و شکم عالی است. فنر منفصل هر فنر را در جیب جدا قرار می‌دهد؛ بنابراین لرزش غلت‌زدن همسرتان منتقل نمی‌شود. اگر تخت دونفره و سبک‌خواب هستید، منفصل؛ اگر سفتی کامل و قیمت مناسب می‌خواهید، متصل." },
  { q: "ریباند دقیقاً چیست و برای چه کسانی است؟", a: "ریباند فوم خردشده فشرده‌شده با چگالی بسیار بالاست؛ کاملاً بدون فنر، بی‌صدا و بدون انتقال حرکت. بهترین انتخاب برای دیسک، مهره‌های کمر، افراد سنگین‌وزن و کسانی است که باید روی سطح کاملاً یکنواخت بخوابند." },
  { q: "فوم سنگین با ریباند چه فرقی دارد؟", a: "هر دو بدون فنر هستند. فوم سنگین (طبی) نرم‌تر و سبک‌تر است و حس آغوش فوم را می‌دهد؛ ریباند بسیار متراکم‌تر و سفت‌تر است. فوم سنگین برای خواب ترکیبی و ریباند برای دردهای جدی ستون فقرات توصیه می‌شود." },
  { q: "تاپر و محافظ تشک دقیقاً چه فرقی با تشک دارند؟", a: "تاپر لایه‌ای ۳ تا ۸ سانتی‌متری است که روی تشک فعلی پهن می‌شود و سطح آن را نرم/گرم/خنک می‌کند — بدون تعویض کل تشک. محافظ تشک لایه‌ای ضدآب، ضدکنه و قابل شستشو است که مستقیم روی تشک قرار می‌گیرد و آن را از عرق، مایعات و آلودگی بیمه می‌کند. بهترین چیدمان: تشک → محافظ ضدآب → تاپر. هر دو در ۸ سایز ۸۰×۱۸۰ تا ۲۰۰×۲۰۰ موجودند؛ قیمت تاپر ۱۳ تا ۳۰ میلیون و محافظ ۳٫۳ تا ۸٫۲ میلیون تومان." },
  { q: "گارانتی تشک‌های هیگر چطور فعال می‌شود؟", a: "همراه هر تشک، کارت گارانتی با شماره سریال و هولوگرام ارسال می‌شود. شماره سریال را در سایت یا با پیامک فعال کنید؛ از آن تاریخ، ۵ تا ۱۰ سال گارانتی تعویض برای اسکلت، فنر و فوم اعمال می‌شود." },
  { q: "ارسال و نصب به شهرستان‌ها چقدر طول می‌کشد؟", a: "تهران و مازندران ۱ تا ۲ روز کاری؛ سایر استان‌ها ۲ تا ۵ روز کاری با باربری مستقیم کارخانه. نصب تیم هیگر در مقصد هماهنگ می‌شود و هزینه حمل در قیمت نهایی لحاظ شده است." },
  { q: "سایزهای موجود کدام‌اند؟", a: "۹۰×۲۰۰ (یک‌نفره)، ۱۲۰×۲۰۰ (یک‌نفره عریض)، ۱۶۰×۲۰۰ (کینگ)، ۱۸۰×۲۰۰ (سوپرکینگ) و ۲۰۰×۲۰۰ («۲ نفره لوکس»). امکان دوخت سفارشی برای ابعاد خاص تخت‌های قدیمی نیز وجود دارد." },
  { q: "پرداخت چطور انجام می‌شود؟", a: "آنلاین با درگاه امن، کارت‌به‌کارت، یا پرداخت در محل پس از بازبینی سلامت و اصالت تشک هنگام تحویل. برای خریدهای سازمانی و پروژه‌ای، فاکتور رسمی نیز صادر می‌شود." },
];

export default function Extras() {
  const [open, setOpen] = useState(0);

  return (
    <>
      {/* ============ چرا هیگر؟ ============ */}
      <section className="relative overflow-hidden bg-hg-cream py-16 lg:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="grid items-center gap-10 lg:grid-cols-12">
            <div className="relative lg:col-span-5">
              <figure className="overflow-hidden rounded-3xl border border-hg-line shadow-[0_30px_60px_rgba(16,36,62,0.25)]">
                {asset("factory") ? (
                  <img src={asset("factory")} alt="شوروم کارخانه تشک هیگر با ردیف تشک‌ها و نورپردازی گرم" loading="lazy" className="aspect-[4/4.6] w-full object-cover sm:aspect-[4/3.4] lg:aspect-[4/4.8]" />
                ) : (
                  <div aria-hidden="true" className="midnight grid-lines aspect-[4/4.6] w-full sm:aspect-[4/3.4] lg:aspect-[4/4.8]" />
                )}
              </figure>
              <div className="absolute -bottom-5 right-4 rounded-2xl border border-hg-gold-500/40 bg-hg-navy-900 px-5 py-3 text-center shadow-xl">
                <p className="text-2xl font-black text-hg-gold-400">{toFa(100000)}+</p>
                <p className="text-[9px] font-bold text-hg-cream/80">تشک تحویل‌شده در ایران</p>
              </div>
            </div>
            <div className="lg:col-span-7">
              <p className="inline-flex items-center gap-2 rounded-full border border-hg-gold-500/50 bg-white/70 px-4 py-1.5 text-[10px] font-bold text-hg-gold-600">چرا تشک هیگر؟</p>
              <h2 className="mt-4 text-3xl font-black leading-snug text-hg-navy-900 sm:text-4xl">از کارخانه <span className="gold-text">تا اتاق خواب شما</span></h2>
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                {ADVANTAGES.map(({ icon: Icon, title, text }) => (
                  <div key={title} className="group flex items-start gap-3 rounded-2xl border border-hg-line bg-white/70 p-4 transition hover:border-hg-gold-500/60 hover:bg-white">
                    <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-hg-navy-900 text-hg-gold-400 transition group-hover:scale-110">
                      <Icon size={20} strokeWidth={2} />
                    </span>
                    <span>
                      <span className="block text-[11px] font-black text-hg-navy-900">{title}</span>
                      <span className="mt-1 block text-[9px] leading-5 text-hg-navy-600">{text}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ سوالات متداول ============ */}
      <section id="faq" className="paper-texture border-t border-hg-line py-16 lg:py-20">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <p className="inline-flex items-center gap-2 rounded-full border border-hg-gold-500/50 bg-white/70 px-4 py-1.5 text-[10px] font-bold text-hg-gold-600">سوال‌های پرتکرار</p>
            <h2 className="mt-4 text-3xl font-black leading-snug text-hg-navy-900">قبل از خرید،<br /><span className="gold-text">این‌ها را بدانید</span></h2>
            <p className="mt-3 text-sm leading-7 text-hg-navy-700">پاسخ کوتاه و صادقانه به رایج‌ترین سوال‌های مشتریان فروشگاه هیگر. سوال دیگری دارید؟ همین حالا زنگ بزنید:</p>
            <a href="tel:+989116406485" className="btn-gold mt-5 px-6 py-3.5 text-xs" dir="ltr">۰۹۱۱۶۴۰۶۴۸۵</a>
          </div>
          <div className="lg:col-span-8">
            <div className="divide-y divide-hg-line overflow-hidden rounded-2xl border border-hg-line bg-white shadow-sm">
              {FAQS.map((item, i) => {
                const isOpen = open === i;
                return (
                  <div key={i}>
                    <button onClick={() => setOpen(isOpen ? -1 : i)} className="flex w-full items-center justify-between gap-4 px-5 py-4 text-right transition hover:bg-hg-cream/60" aria-expanded={isOpen}>
                      <span className="text-[12px] font-black text-hg-navy-900">{item.q}</span>
                      <ChevronDown size={18} className={`shrink-0 text-hg-gold-600 transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`} />
                    </button>
                    {isOpen && <div className="fade-up px-5 pb-5 text-[11px] leading-7 text-hg-navy-700">{item.a}</div>}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
