import { Phone, Sparkles, Factory, MoonStar, Layers3, Star } from "lucide-react";
import { STORE } from "../data";
import { asset } from "../embed-config";

const MARQUEE = [
  "گارانتی شرکتی ۵ تا ۱۰ ساله",
  "تولید تخصصی از سال ۱۳۸۷",
  "۲۷+ مدل در ۴ هسته اصلی",
  "ارسال و نصب مستقیم از کارخانه",
  "مشاوره و گارانتی تعویض رایگان",
  "فنر متصل • فنر منفصل • ریباند • فوم سنگین",
  "پرداخت در محل پس از بررسی سلامت تشک",
];

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden bg-hg-navy-950 text-hg-cream">
      {/* لایه ۱: عکس پس‌زمینه */}
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-cover bg-no-repeat"
        style={{
          backgroundColor: "#0b1a30",
          backgroundImage: asset("hero") ? `url('${asset("hero")}')` : undefined,
          backgroundPosition: "center 45%",
        }}
      />
      {/* لایه ۲: سایه سرمه‌ای برای خوانایی متن روی عکس */}
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(to left, rgba(7,15,29,0.95) 0%, rgba(7,15,29,0.88) 36%, rgba(7,15,29,0.52) 72%, rgba(7,15,29,0.32) 100%)",
        }}
      />
      {/* روی موبایل عکس بیشتر در سايه می‌رود چون متن تمام عرض را می‌گیرد */}
      <div aria-hidden="true" className="absolute inset-0 bg-hg-navy-950/55 lg:hidden" />
      <div aria-hidden="true" className="grid-lines absolute inset-0 opacity-40" />

      <div className="relative mx-auto max-w-7xl px-4 pb-16 pt-16 sm:px-6 lg:pb-28 lg:pt-24">
        <div className="max-w-xl lg:max-w-[37rem]">
          <div className="fade-up inline-flex items-center gap-2 rounded-full border border-hg-gold-500/40 bg-hg-navy-950/55 px-4 py-1.5 text-[11px] font-bold text-hg-gold-300 backdrop-blur-sm">
            <Sparkles size={13} strokeWidth={2.5} />
            تولید تخصصی تشک هیگر — از سال {STORE.est}
            <span className="h-1 w-1 rounded-full bg-hg-gold-400" />
            ۲۷ مدل فعال
          </div>

          <h1
            className="fade-up mt-5 text-4xl font-black leading-[1.25] tracking-tight text-hg-cream drop-shadow-[0_2px_14px_rgba(7,15,29,0.55)] sm:text-5xl xl:text-[3.6rem]"
            style={{ animationDelay: "80ms" }}
          >
            خوابی که ستون فقراتت
            <br />
            <span className="gold-text">فردا صبح ممنونت می‌شود</span>
          </h1>

          <p
            className="fade-up mt-5 max-w-xl text-[15px] leading-8 text-hg-gold-200/90"
            style={{ animationDelay: "160ms" }}
          >
            قد، وزن، سن و سبک خواب شما را به <strong className="text-hg-gold-300">«تشک‌سنج هیگر»</strong> بگویید؛
            الگوریتم ارگونومی ما از میان ۴ هسته اصلی تشک، دقیق‌ترین مدل سازگار با بدن شما را با
            <strong> درصد تطبیق علمی</strong> پیشنهاد می‌کند.
          </p>

          <div className="fade-up mt-7 flex flex-wrap items-center gap-3" style={{ animationDelay: "240ms" }}>
            <a href="#tashik-sanj" className="btn-gold px-7 py-4 text-sm">
              <MoonStar size={18} strokeWidth={2.4} />
              شروع تشک‌سنج — رایگان
            </a>
            <a href="#products" className="btn-outline px-6 py-4 text-sm">
              دیدن ۲۷+ مدل تشک
            </a>
          </div>

          {/* آمارهای کلیدی */}
          <dl className="fade-up mt-9 grid max-w-lg grid-cols-3 gap-3" style={{ animationDelay: "320ms" }}>
            {[
              { n: "۱۶+", d: "سال سابقه تولید", icon: Factory },
              { n: "۲۷+", d: "مدل در ۴ هسته", icon: Layers3 },
              { n: "۹۸٪", d: "رضایت پس از راهنما", icon: Star },
            ].map(({ n, d, icon: Icon }) => (
              <div key={d} className="rounded-2xl border border-white/10 bg-hg-navy-950/60 px-3 py-3 text-center backdrop-blur-sm">
                <Icon size={15} className="mx-auto mb-1.5 text-hg-gold-400" strokeWidth={2.2} />
                <dt className="text-2xl font-black text-hg-gold-300">{n}</dt>
                <dd className="mt-1 text-[10px] leading-4 text-hg-cream/75">{d}</dd>
              </div>
            ))}
          </dl>
        </div>

        {/* کارت تماس، روی خودِ عکس در دسکتاپ */}
        <a
          href={STORE.telHref}
          className="glass-card floaty absolute bottom-24 left-6 hidden items-center gap-3 rounded-2xl px-5 py-4 transition-colors hover:border-hg-gold-500/50 xl:flex"
        >
          <span className="grid h-12 w-12 place-items-center rounded-xl bg-hg-gold-500 text-hg-navy-900">
            <Phone size={20} strokeWidth={2.4} />
          </span>
          <span>
            <span className="block text-[10px] text-hg-cream/70">مشاوره تلفنی رایگان</span>
            <span className="block text-sm font-black tracking-wide text-white" dir="ltr">{STORE.phone}</span>
          </span>
        </a>
      </div>

      {/* ===== نوار اعتماد ===== */}
      <div className="relative border-y border-hg-gold-500/25 bg-hg-navy-950/80 py-2.5 backdrop-blur">
        <div className="marquee overflow-hidden" aria-hidden="true">
          <div className="marquee-track flex items-center gap-10 whitespace-nowrap text-[11px] font-bold text-hg-gold-200/90">
            {[...MARQUEE, ...MARQUEE].map((t, i) => (
              <span key={i} className="flex items-center gap-3">
                <span className="inline-block h-1.5 w-1.5 rotate-45 bg-hg-gold-500" />
                {t}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
