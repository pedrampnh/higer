import { useMemo, useState } from "react";
import {
  Baby, Zap, Briefcase, Accessibility, User, Users, Heart, Bone, Disc3, Smile, Footprints,
  ShieldCheck, Snowflake, VolumeX, BadgeCheck, Wallet, Cloud, ChevronRight, ChevronLeft,
  Sparkles, RotateCcw, Phone, ExternalLink, Check, Ruler, Weight, Stethoscope, Scale,
  Star, BedDouble, Table2,
} from "lucide-react";
import {
  analyze, DEFAULT_ANSWERS, bmiOf, bmiStatus, desiredFirmness, type FinderAnswers, type AgeKey,
  type PositionKey, type PainKey, type SleepersKey, type PriorityKey, type ScoredProduct,
} from "../recommend";
import { CORE_META, STORE, shopSearchUrl, type Product } from "../data";
import { faMillion, faPrice, toFa } from "../utils/fa";

const TOTAL_STEPS = 8;

const STEP_TITLES = [
  "سن شما",
  "قد و وزن",
  "وضعیت خواب",
  "مشکل یا درد جسمی",
  "همراه تخت",
  "سفتی دلخواه",
  "بودجه شما",
  "اولویت اصلی",
];

const AGE_OPTIONS: Array<{ key: AgeKey; label: string; sub: string; icon: typeof Baby }> = [
  { key: "teen", label: "زیر ۱۸ سال", sub: "دوران رشد و دانش‌آموز", icon: Baby },
  { key: "young", label: "۱۸ تا ۳۵ سال", sub: "دانشجو و جوانان", icon: Zap },
  { key: "adult", label: "۳۶ تا ۵۵ سال", sub: "میانسال — بیشترین مراجعه", icon: Briefcase },
  { key: "senior", label: "بالای ۵۵ سال", sub: "نیازمند تسکین فشار", icon: Accessibility },
];

const POSITION_OPTIONS: Array<{ key: PositionKey; label: string; sub: string }> = [
  { key: "back", label: "خواب پشت", sub: "رایج‌ترین حالت — فشار روی کمر" },
  { key: "side", label: "خواب پهلو", sub: "نیازمند نرمی شانه و لگن" },
  { key: "stomach", label: "روی شکم", sub: "نیازمند سطح کاملاً سفت" },
  { key: "combo", label: "ترکیبی", sub: "دائم در حال تغییر وضعیت" },
];

const PAIN_OPTIONS: Array<{ key: PainKey; label: string; icon: typeof Smile }> = [
  { key: "none", label: "بدون مشکل خاص", icon: Smile },
  { key: "back", label: "کمردرد", icon: Bone },
  { key: "disc", label: "دیسک و مهره", icon: Disc3 },
  { key: "neck", label: "گردن و شانه", icon: Accessibility },
  { key: "joint", label: "مفصل و زانو", icon: Footprints },
];

const SLEEPER_OPTIONS: Array<{ key: SleepersKey; label: string; sub: string; icon: typeof User }> = [
  { key: "single", label: "تک‌نفره", sub: "فقط خودم می‌خوابم", icon: User },
  { key: "coupleCalm", label: "دونفره آرام", sub: "حرکت کم، خواب آرام", icon: Heart },
  { key: "coupleMoving", label: "دونفره پرتحرک", sub: "یکی زیاد غلت می‌زند", icon: Users },
];

const BUDGET_OPTIONS: Array<{ key: 1 | 2 | 3 | 4; label: string; sub: string }> = [
  { key: 1, label: "تا ۳۰ میلیون", sub: "اقتصادی و قابل‌اعتماد" },
  { key: 2, label: "۳۰ تا ۶۰ میلیون", sub: "میان‌رده — بهترین ارزش خرید" },
  { key: 3, label: "۶۰ تا ۱۵۰ میلیون", sub: "پرمیوم — تجربه هتلینگ" },
  { key: 4, label: "بالای ۱۵۰ میلیون", sub: "لوکس — الدورادو سوپرلوکس" },
];

const PRIORITY_OPTIONS: Array<{ key: PriorityKey; label: string; icon: typeof Cloud }> = [
  { key: "ortho", label: "ارتوپدیک و درمان", icon: Bone },
  { key: "cool", label: "خنکی و تهویه", icon: Snowflake },
  { key: "quiet", label: "بی‌صدایی کامل", icon: VolumeX },
  { key: "warranty", label: "گارانتی بلندمدت", icon: BadgeCheck },
  { key: "price", label: "قیمت مناسب", icon: Wallet },
  { key: "soft", label: "نرمی مجلل", icon: Cloud },
];

const FIRMNESS_STOPS = [
  { v: 5, label: "خیلی سفت" },
  { v: 4, label: "سفت" },
  { v: 3, label: "متوسط" },
  { v: 2, label: "نرم" },
  { v: 1, label: "خیلی نرم" },
];

function PositionGlyph({ kind, active }: { kind: PositionKey; active: boolean }) {
  const stroke = active ? "#10243e" : "#d9a13b";
  const common = { stroke, strokeWidth: 2.4, strokeLinecap: "round" as const, fill: "none" };
  return (
    <svg viewBox="0 0 72 44" className="h-12 w-20" aria-hidden="true">
      {/* بستر */}
      <line x1="4" y1="36" x2="68" y2="36" {...common} opacity="0.55" />
      {kind === "back" && (
        <g {...common}>
          <circle cx="14" cy="28" r="4.5" />
          <path d="M20 29h26c6 0 10 3 12 7" />
          <path d="M34 29v-6" opacity="0.7" />
        </g>
      )}
      {kind === "side" && (
        <g {...common}>
          <circle cx="13" cy="27" r="4.5" />
          <path d="M19 28c8 0 9-5 16-5s10 5 10 5l10 3" />
          <path d="M22 33c6 2 12 2 18 0" opacity="0.7" />
        </g>
      )}
      {kind === "stomach" && (
        <g {...common}>
          <circle cx="13" cy="29" r="4.5" />
          <path d="M19 30h30c6 0 9-3 10-8" />
          <path d="M30 30v-4" opacity="0.7" />
        </g>
      )}
      {kind === "combo" && (
        <g {...common}>
          <circle cx="13" cy="28" r="4.5" />
          <path d="M19 29h18" />
          <path d="M44 17a7 7 0 1 1-2 5" />
          <path d="M44 12v6h-6" />
        </g>
      )}
    </svg>
  );
}

function SpecBar({ label, value, delay }: { label: string; value: number; delay: number }) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-[10px] font-bold text-hg-navy-800">
        <span>{label}</span>
        <span dir="ltr">{toFa(value)}/۵</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-hg-paper">
        <div className="bar-grow h-full rounded-full bg-gradient-to-l from-hg-gold-500 to-hg-gold-600" style={{ width: `${(value / 5) * 100}%`, animationDelay: `${delay}ms` }} />
      </div>
    </div>
  );
}

function MatchRing({ pct }: { pct: number }) {
  const R = 40;
  const C = 2 * Math.PI * R;
  const shown = Math.round((pct / 100) * C);
  return (
    <div className="relative h-24 w-24 shrink-0">
      <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
        <circle cx="50" cy="50" r={R} fill="none" stroke="#ece7d8" strokeWidth="10" />
        <circle
          cx="50" cy="50" r={R} fill="none" stroke="url(#goldGrad)" strokeWidth="10" strokeLinecap="round"
          strokeDasharray={`${shown} ${C}`} className="ring-anim" style={{ ["--ring-c" as string]: C }}
        />
        <defs>
          <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#e7b95c" />
            <stop offset="55%" stopColor="#d9a13b" />
            <stop offset="100%" stopColor="#a86f1c" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-xl font-black leading-none text-hg-navy-900">{toFa(pct)}٪</span>
        <span className="mt-0.5 text-[8px] font-bold text-hg-navy-600">تطبیق</span>
      </div>
    </div>
  );
}

export default function Finder() {
  const [answers, setAnswers] = useState<FinderAnswers>(DEFAULT_ANSWERS);
  const [step, setStep] = useState(1);
  const [results, setResults] = useState<ScoredProduct[] | null>(null);
  const [showCompare, setShowCompare] = useState(false);

  const bmi = bmiOf(answers.weight, answers.height);
  const bmiInfo = bmiStatus(bmi);
  const progress = results ? 100 : Math.round(((step - 1) / TOTAL_STEPS) * 100 + 100 / TOTAL_STEPS / 2);

  const stepValid = useMemo(() => {
    switch (step) {
      case 1: return answers.age !== null;
      case 2: return true;
      case 3: return answers.position !== null;
      case 4: return answers.pain !== null;
      case 5: return answers.sleepers !== null;
      case 6: return true;
      case 7: return answers.budget !== null;
      case 8: return answers.priority !== null;
      default: return false;
    }
  }, [step, answers]);

  const set = <K extends keyof FinderAnswers>(key: K, value: FinderAnswers[K]) =>
    setAnswers((p) => ({ ...p, [key]: value }));

  const goNext = () => {
    if (!stepValid) return;
    if (step < TOTAL_STEPS) setStep((s) => s + 1);
    else setResults(analyze(answers));
  };
  const goBack = () => (results ? setResults(null) : setStep((s) => Math.max(1, s - 1)));
  const restart = () => {
    setAnswers(DEFAULT_ANSWERS);
    setStep(1);
    setResults(null);
    setShowCompare(false);
  };

  const bmiTone =
    bmiInfo.tone === "ok" ? "bg-emerald-100 text-emerald-800 border-emerald-300"
    : bmiInfo.tone === "warn" ? "bg-amber-100 text-amber-900 border-amber-300"
    : bmiInfo.tone === "high" ? "bg-red-100 text-red-800 border-red-300"
    : "bg-sky-100 text-sky-800 border-sky-300";

  const bmiPct = Math.min(100, Math.max(0, ((bmi - 14) / (38 - 14)) * 100));

  return (
    <section id="tashik-sanj" className="relative overflow-hidden bg-hg-paper py-16 lg:py-24">
      {/* پس‌زمینه دکوراتیو */}
      <div aria-hidden="true" className="pointer-events-none absolute -right-32 top-10 h-80 w-80 rounded-full opacity-20 blur-3xl" style={{ background: "radial-gradient(circle,#d9a13b,transparent 70%)" }} />
      <div aria-hidden="true" className="pointer-events-none absolute -left-32 bottom-10 h-80 w-80 rounded-full opacity-15 blur-3xl" style={{ background: "radial-gradient(circle,#10243e,transparent 70%)" }} />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        {/* سربرگ بخش */}
        <div className="mx-auto max-w-3xl text-center">
          <p className="inline-flex items-center gap-2 rounded-full border border-hg-gold-500/50 bg-white/70 px-4 py-1.5 text-[10px] font-bold tracking-wide text-hg-gold-600">
            <Sparkles size={12} /> الگوریتم اختصاصی ارگونومی هیگر
          </p>
          <h2 className="mt-4 text-3xl font-black leading-snug text-hg-navy-900 sm:text-4xl">
            تشکِ ایده‌آلِ بدنِ شما <span className="gold-text">کدام است؟</span>
          </h2>
          <p className="mt-3 text-sm leading-7 text-hg-navy-700">
            ۸ سؤال کوتاه درباره سن، وزن، سبک خواب و بودجه شما می‌پرسیم؛ سپس از میان ۲۷ مدل تشک هیگر،
            <strong> سه پیشنهاد با درصد تطبیق</strong> دریافت می‌کنید. بدون شماره موبایل، کاملاً رایگان.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-12">
          {/* ============ کارت اصلی تشک‌سنج ============ */}
          <div className="lg:col-span-8">
            <div className="overflow-hidden rounded-3xl border border-hg-line bg-white shadow-[0_30px_70px_rgba(16,36,62,0.18)]">
              {/* نوار پیشرفت */}
              <div className="border-b border-hg-line bg-hg-cream/60 px-5 py-4 sm:px-7">
                <div className="flex items-center justify-between text-[11px] font-bold text-hg-navy-800">
                  <span>{results ? "نتایج آماده است" : `مرحله ${toFa(step)} از ${toFa(TOTAL_STEPS)} — ${STEP_TITLES[step - 1]}`}</span>
                  <span dir="ltr">{toFa(progress)}٪</span>
                </div>
                <div className="mt-2 h-2 overflow-hidden rounded-full bg-hg-line">
                  <div
                    className="h-full rounded-full bg-gradient-to-l from-hg-gold-400 via-hg-gold-500 to-hg-gold-600 transition-all duration-500"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                {/* نقطه‌های مراحل */}
                <ol className="mt-3 flex items-center justify-between" aria-hidden="true">
                  {STEP_TITLES.map((t, i) => {
                    const n = i + 1;
                    const done = results || n < step;
                    const current = !results && n === step;
                    return (
                      <li key={t} className="flex flex-col items-center gap-1">
                        <button
                          type="button"
                          tabIndex={-1}
                          className={`grid h-6 w-6 place-items-center rounded-full text-[9px] font-black transition-all sm:h-7 sm:w-7 sm:text-[10px] ${
                            done ? "bg-hg-navy-900 text-hg-gold-400" : current ? "scale-125 border-2 border-hg-gold-500 bg-white text-hg-gold-600" : "bg-hg-line text-hg-navy-600"
                          }`}
                        >
                          {done ? <Check size={11} strokeWidth={3.5} /> : toFa(n)}
                        </button>
                        <span className={`hidden text-[8px] font-bold sm:block ${current ? "text-hg-gold-600" : "text-hg-navy-600/70"}`}>{t}</span>
                      </li>
                    );
                  })}
                </ol>
              </div>

              {/* ============ بدنه: فرم یا نتیجه ============ */}
              <div className="p-5 sm:p-7">
                {!results ? (
                  <div key={step} className="fade-up">
                    {/* --- مرحله ۱: سن --- */}
                    {step === 1 && (
                      <fieldset>
                        <legend className="text-lg font-black text-hg-navy-900">سن شما چقدر است؟</legend>
                        <p className="mt-1 text-xs text-hg-navy-600">سن، چگالی استخوان و نیاز حمایت ستون فقرات را تعیین می‌کند.</p>
                        <div className="mt-5 grid gap-3 sm:grid-cols-2">
                          {AGE_OPTIONS.map(({ key, label, sub, icon: Icon }) => (
                            <button key={key} type="button" className="hg-choice flex items-center gap-4 p-4 text-right" data-active={answers.age === key} onClick={() => set("age", key)} aria-pressed={answers.age === key}>
                              <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-hg-navy-900 text-hg-gold-400">
                                <Icon size={26} strokeWidth={1.8} />
                              </span>
                              <span>
                                <span className="block text-sm font-black text-hg-navy-900">{label}</span>
                                <span className="mt-0.5 block text-[10px] leading-4 text-hg-navy-600">{sub}</span>
                              </span>
                            </button>
                          ))}
                        </div>
                      </fieldset>
                    )}

                    {/* --- مرحله ۲: قد و وزن --- */}
                    {step === 2 && (
                      <fieldset>
                        <legend className="text-lg font-black text-hg-navy-900">قد و وزن شما؟</legend>
                        <p className="mt-1 text-xs text-hg-navy-600">این دو عدد، فشار نقطه‌ای و سفتی ایده‌آل هسته را مشخص می‌کنند.</p>

                        <div className="mt-6 space-y-6">
                          {/* وزن */}
                          <div className="rounded-2xl border border-hg-line bg-hg-cream/50 p-4">
                            <div className="flex items-center justify-between">
                              <label htmlFor="hg-w" className="flex items-center gap-2 text-xs font-bold text-hg-navy-800"><Weight size={14} className="text-hg-gold-600" /> وزن بدن</label>
                              <output className="text-2xl font-black text-hg-navy-900">{toFa(answers.weight)} <small className="text-[10px] font-bold text-hg-navy-600">کیلوگرم</small></output>
                            </div>
                            <input id="hg-w" type="range" min={35} max={180} step={1} value={answers.weight}
                              onChange={(e) => set("weight", Number(e.target.value))}
                              className="hg-range mt-3" style={{ ["--fill" as string]: `${((answers.weight - 35) / (180 - 35)) * 100}%` }} aria-valuetext={`${answers.weight} کیلوگرم`} />
                            <div className="mt-1 flex justify-between text-[9px] font-bold text-hg-navy-600/70"><span>۳۵</span><span>۱۱۰</span><span>۱۸۰+</span></div>
                          </div>

                          {/* قد */}
                          <div className="rounded-2xl border border-hg-line bg-hg-cream/50 p-4">
                            <div className="flex items-center justify-between">
                              <label htmlFor="hg-h" className="flex items-center gap-2 text-xs font-bold text-hg-navy-800"><Ruler size={14} className="text-hg-gold-600" /> قد</label>
                              <output className="text-2xl font-black text-hg-navy-900">{toFa(answers.height)} <small className="text-[10px] font-bold text-hg-navy-600">سانتی‌متر</small></output>
                            </div>
                            <input id="hg-h" type="range" min={130} max={220} step={1} value={answers.height}
                              onChange={(e) => set("height", Number(e.target.value))}
                              className="hg-range mt-3" style={{ ["--fill" as string]: `${((answers.height - 130) / (220 - 130)) * 100}%` }} aria-valuetext={`${answers.height} سانتی‌متر`} />
                            <div className="mt-1 flex justify-between text-[9px] font-bold text-hg-navy-600/70"><span>۱۳۰</span><span>۱۷۵</span><span>۲۲۰</span></div>
                          </div>

                          {/* BMI زنده */}
                          <div className="flex flex-col gap-3 rounded-2xl border border-hg-navy-900/10 bg-hg-navy-900 p-4 text-hg-cream sm:flex-row sm:items-center sm:justify-between">
                            <div className="flex items-center gap-3">
                              <span className="grid h-12 w-12 place-items-center rounded-xl bg-hg-gold-500 text-hg-navy-900"><Scale size={22} strokeWidth={2.2} /></span>
                              <span>
                                <span className="block text-[10px] font-bold text-hg-gold-300">شاخص توده بدنی (BMI)</span>
                                <span className="text-2xl font-black text-white" dir="ltr">{bmi.toFixed(1)}</span>
                              </span>
                            </div>
                            <div className="w-full sm:w-56">
                              <span className={`inline-block rounded-full border px-3 py-1 text-[10px] font-black ${bmiTone}`}>{bmiInfo.label}</span>
                              <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/15" aria-hidden="true">
                                <div className="h-full rounded-full bg-gradient-to-l from-hg-gold-300 to-hg-gold-500 transition-all duration-300" style={{ width: `${bmiPct}%` }} />
                              </div>
                              <p className="mt-1.5 text-[9px] text-hg-cream/60">سفتی پیشنهادی الگوریتم: «{FIRMNESS_STOPS.find((f) => f.v === Math.round(desiredFirmness(answers)))?.label}»</p>
                            </div>
                          </div>
                        </div>
                      </fieldset>
                    )}

                    {/* --- مرحله ۳: وضعیت خواب --- */}
                    {step === 3 && (
                      <fieldset>
                        <legend className="text-lg font-black text-hg-navy-900">معمولاً در چه وضعیتی می‌خوابید؟</legend>
                        <p className="mt-1 text-xs text-hg-navy-600">پهلوخواب‌ها به سطح نرم‌تر و پشت‌خواب‌ها به حمایت یکنواخت نیاز دارند.</p>
                        <div className="mt-5 grid gap-3 sm:grid-cols-2">
                          {POSITION_OPTIONS.map(({ key, label, sub }) => (
                            <button key={key} type="button" className="hg-choice flex flex-col items-center gap-1 p-4" data-active={answers.position === key} onClick={() => set("position", key)} aria-pressed={answers.position === key}>
                              <PositionGlyph kind={key} active={answers.position === key} />
                              <span className="text-sm font-black text-hg-navy-900">{label}</span>
                              <span className="text-[10px] text-hg-navy-600">{sub}</span>
                            </button>
                          ))}
                        </div>
                      </fieldset>
                    )}

                    {/* --- مرحله ۴: درد --- */}
                    {step === 4 && (
                      <fieldset>
                        <legend className="text-lg font-black text-hg-navy-900">مشکل جسمی یا درد مزمن دارید؟</legend>
                        <p className="mt-1 text-xs text-hg-navy-600">پاسخ صادقانه شما، تفاوت بین «خواب معمولی» و «خواب درمانی» است.</p>
                        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
                          {PAIN_OPTIONS.map(({ key, label, icon: Icon }) => (
                            <button key={key} type="button" className="hg-choice flex flex-col items-center gap-2 px-2 py-4" data-active={answers.pain === key} onClick={() => set("pain", key)} aria-pressed={answers.pain === key}>
                              <Icon size={26} strokeWidth={1.8} className="text-hg-navy-800" />
                              <span className="text-[11px] font-black text-hg-navy-900">{label}</span>
                            </button>
                          ))}
                        </div>
                        {answers.pain === "disc" || answers.pain === "back" ? (
                          <p className="fade-up mt-3 flex items-start gap-2 rounded-xl border border-hg-gold-500/40 bg-hg-gold-200/30 p-3 text-[10px] leading-5 text-hg-navy-800">
                            <Stethoscope size={14} className="mt-0.5 shrink-0 text-hg-gold-600" />
                            برای دیسک و مهره‌ها، هسته‌های «ریباند ارتوپدیک» یا «فوم سنگین چگال» بیشترین شواهد حمایت یکنواخت را دارند؛ این را در امتیازدهی لحاظ می‌کنیم.
                          </p>
                        ) : null}
                      </fieldset>
                    )}

                    {/* --- مرحله ۵: همراه تخت --- */}
                    {step === 5 && (
                      <fieldset>
                        <legend className="text-lg font-black text-hg-navy-900">تخت را با چه کسی شریک هستید؟</legend>
                        <p className="mt-1 text-xs text-hg-navy-600">مهم‌ترین پرسش برای تخت‌های دو نفره؛ ایزولاسیون حرکت تعیین‌کننده آرامش است.</p>
                        <div className="mt-5 grid gap-3 sm:grid-cols-3">
                          {SLEEPER_OPTIONS.map(({ key, label, sub, icon: Icon }) => (
                            <button key={key} type="button" className="hg-choice flex flex-col items-center gap-2 p-5 text-center" data-active={answers.sleepers === key} onClick={() => set("sleepers", key)} aria-pressed={answers.sleepers === key}>
                              <Icon size={30} strokeWidth={1.7} className="text-hg-navy-800" />
                              <span className="text-xs font-black text-hg-navy-900">{label}</span>
                              <span className="text-[9px] leading-4 text-hg-navy-600">{sub}</span>
                            </button>
                          ))}
                        </div>
                      </fieldset>
                    )}

                    {/* --- مرحله ۶: سفتی --- */}
                    {step === 6 && (
                      <fieldset>
                        <legend className="text-lg font-black text-hg-navy-900">حس ایده‌آل سطح تشک چیست؟</legend>
                        <p className="mt-1 text-xs text-hg-navy-600">الگوریتم این انتخاب را با وزن و وضعیت خواب شما بازکالیبره می‌کند.</p>
                        <div className="mt-6 grid grid-cols-5 gap-2" role="radiogroup" aria-label="میزان سفتی">
                          {FIRMNESS_STOPS.map(({ v, label }) => (
                            <button key={v} type="button" role="radio" aria-checked={answers.firmness === v}
                              onClick={() => set("firmness", v)}
                              className={`flex flex-col items-center gap-2 rounded-2xl border-2 py-4 transition-all ${
                                answers.firmness === v
                                  ? "border-hg-gold-500 bg-gradient-to-b from-hg-gold-200/70 to-hg-gold-200/20 shadow-[0_10px_24px_rgba(217,161,59,0.35)]"
                                  : "border-hg-line bg-white hover:border-hg-gold-400"
                              }`}>
                              <span className={`grid h-9 w-9 place-items-center rounded-full text-sm font-black ${answers.firmness === v ? "bg-hg-navy-900 text-hg-gold-400" : "bg-hg-paper text-hg-navy-800"}`}>{toFa(v)}</span>
                              <span className="text-[9px] font-black leading-4 text-hg-navy-900 sm:text-[10px]">{label}</span>
                            </button>
                          ))}
                        </div>
                        <p className="mt-3 text-center text-[10px] font-bold text-hg-navy-600">چپ = نرم‌تر (ابر و مموری فوم) • راست = سفت ارتوپدیک (ریباند و فنر بونل)</p>
                      </fieldset>
                    )}

                    {/* --- مرحله ۷: بودجه --- */}
                    {step === 7 && (
                      <fieldset>
                        <legend className="text-lg font-black text-hg-navy-900">بازه بودجه شما؟</legend>
                        <p className="mt-1 text-xs text-hg-navy-600">بر اساس قیمت‌های فروشگاه higermattress.ir — بدون هزینه پنهان و نصب رایگان.</p>
                        <div className="mt-5 grid gap-3 sm:grid-cols-2">
                          {BUDGET_OPTIONS.map(({ key, label, sub }) => (
                            <button key={key} type="button" className="hg-choice flex items-center gap-3 p-4 text-right" data-active={answers.budget === key} onClick={() => set("budget", key)} aria-pressed={answers.budget === key}>
                              <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-xl text-lg font-black ${answers.budget === key ? "bg-hg-navy-900 text-hg-gold-400" : "bg-hg-paper text-hg-navy-800"}`}>{toFa(key)}</span>
                              <span>
                                <span className="block text-xs font-black text-hg-navy-900">{label}</span>
                                <span className="mt-0.5 block text-[9px] text-hg-navy-600">{sub}</span>
                              </span>
                            </button>
                          ))}
                        </div>
                      </fieldset>
                    )}

                    {/* --- مرحله ۸: اولویت --- */}
                    {step === 8 && (
                      <fieldset>
                        <legend className="text-lg font-black text-hg-navy-900">مهم‌ترین اولویت شما چیست؟</legend>
                        <p className="mt-1 text-xs text-hg-navy-600">آخرین وزن‌دهی الگوریتم؛ چیزی که بیش از هر چیز دیگری برایتان مهم است.</p>
                        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3">
                          {PRIORITY_OPTIONS.map(({ key, label, icon: Icon }) => (
                            <button key={key} type="button" className="hg-choice flex flex-col items-center gap-2 px-2 py-4" data-active={answers.priority === key} onClick={() => set("priority", key)} aria-pressed={answers.priority === key}>
                              <Icon size={26} strokeWidth={1.8} className="text-hg-navy-800" />
                              <span className="text-[11px] font-black text-hg-navy-900">{label}</span>
                            </button>
                          ))}
                        </div>
                      </fieldset>
                    )}

                    {/* ناوبری فرم */}
                    <div className="mt-7 flex items-center justify-between gap-3 border-t border-hg-line pt-5">
                      <button type="button" onClick={step === 1 ? undefined : goBack} disabled={step === 1}
                        className="inline-flex items-center gap-1.5 rounded-full border border-hg-line px-5 py-3 text-xs font-bold text-hg-navy-800 transition enabled:hover:bg-hg-paper disabled:opacity-0">
                        <ChevronRight size={16} /> مرحله قبل
                      </button>
                      {!stepValid && <span className="hidden text-[10px] font-bold text-amber-700 sm:block">برای ادامه یکی از گزینه‌ها را انتخاب کنید</span>}
                      <button type="button" onClick={goNext} disabled={!stepValid}
                        className={`inline-flex items-center gap-2 rounded-full px-6 py-3 text-xs font-black transition-all ${
                          step === TOTAL_STEPS
                            ? "btn-gold"
                            : "bg-hg-navy-900 text-hg-gold-300 enabled:hover:bg-hg-navy-800 disabled:cursor-not-allowed disabled:opacity-40"
                        }`}>
                        {step === TOTAL_STEPS ? (
                          <>نمایش تشک‌های مناسب من <Sparkles size={16} /></>
                        ) : (
                          <>مرحله بعد <ChevronLeft size={16} /></>
                        )}
                      </button>
                    </div>
                  </div>
                ) : (
                  /* ============ نتایج ============ */
                  <div className="fade-up">
                    <div className="flex flex-col items-start justify-between gap-3 sm:flex-row sm:items-center">
                      <div>
                        <h3 className="text-xl font-black text-hg-navy-900">سه تشک برترِ بدن شما</h3>
                        <p className="mt-1 text-[11px] text-hg-navy-600">بر اساس BMI {bmi.toFixed(1)}، {answers.position === "side" ? "خواب پهلو" : answers.position === "back" ? "خواب پشت" : answers.position === "stomach" ? "خواب روی شکم" : "خواب ترکیبی"} و بودجه شما رتبه‌بندی شد.</p>
                      </div>
                      <button onClick={restart} className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-hg-line px-4 py-2 text-[11px] font-bold text-hg-navy-800 transition hover:bg-hg-paper">
                        <RotateCcw size={13} /> شروع مجدد
                      </button>
                    </div>

                    <div className="mt-5 space-y-4">
                      {results.map(({ product: p, pct, reasons }, idx) => {
                        const core = CORE_META[p.core];
                        const best = idx === 0;
                        return (
                          <article key={p.id}
                            className={`relative overflow-hidden rounded-2xl border-2 p-4 transition-all sm:p-5 ${
                              best ? "border-hg-gold-500 bg-gradient-to-l from-hg-gold-200/40 via-[#fffdf4] to-white shadow-[0_18px_44px_rgba(217,161,59,0.28)]" : "border-hg-line bg-white"
                            }`}>
                            {best && (
                              <span className="absolute left-0 top-0 flex items-center gap-1 rounded-br-2xl bg-hg-navy-900 px-3 py-1.5 text-[9px] font-black text-hg-gold-400">
                                <Star size={10} fill="currentColor" /> بهترین تطبیق
                              </span>
                            )}
                            <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
                              <MatchRing pct={pct} />
                              <div className="min-w-0 flex-1">
                                <div className="flex flex-wrap items-center gap-2">
                                  <h4 className="text-lg font-black text-hg-navy-900">{p.fa}</h4>
                                  <span className="text-[9px] font-bold tracking-widest text-hg-navy-500" dir="ltr">{p.en.toUpperCase()}</span>
                                  <span className="inline-flex items-center gap-1 rounded-full bg-hg-navy-900 px-2.5 py-0.5 text-[9px] font-bold text-hg-gold-300">
                                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: core.hue }} />
                                    هسته {core.fa}
                                  </span>
                                  {p.badge && <span className="rounded-full bg-hg-gold-500/20 px-2.5 py-0.5 text-[9px] font-bold text-hg-gold-600">{p.badge}</span>}
                                </div>
                                <p className="mt-1.5 text-[10px] leading-5 text-hg-navy-700">{p.blurb}</p>
                                <div className="mt-3 grid grid-cols-3 gap-3">
                                  <SpecBar label="نرمی سطح" value={6 - p.firm} delay={idx * 120} />
                                  <SpecBar label="حمایت ستون فقرات" value={p.support} delay={idx * 120 + 90} />
                                  <SpecBar label="ایزولاسیون حرکت" value={p.motion} delay={idx * 120 + 180} />
                                </div>
                                <ul className="mt-3 space-y-1">
                                  {reasons.slice(0, 2).map((r, i) => (
                                    <li key={i} className="flex items-start gap-1.5 text-[9px] leading-5 text-hg-navy-700">
                                      <Check size={11} strokeWidth={3.5} className="mt-0.5 shrink-0 text-emerald-600" />
                                      {r}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                              {/* قیمت و CTA */}
                              <div className="flex shrink-0 flex-row items-center justify-between gap-3 border-t border-hg-line pt-3 sm:w-40 sm:flex-col sm:items-end sm:justify-center sm:border-0 sm:pt-0">
                                <div className="sm:text-left">
                                  <p className="text-[9px] font-bold text-hg-navy-600">شروع قیمت</p>
                                  <p className="text-sm font-black text-hg-navy-900" dir="ltr">{faPrice(p.startPrice)}</p>
                                  <p className="mt-0.5 inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[8px] font-bold text-emerald-700"><ShieldCheck size={9} /> {toFa(p.warranty)} سال گارانتی</p>
                                </div>
                                <a href={shopSearchUrl(p.fa)} target="_blank" rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1 rounded-full bg-hg-navy-900 px-4 py-2 text-[10px] font-black text-hg-gold-300 transition hover:bg-hg-navy-800">
                                  سفارش <ExternalLink size={11} />
                                </a>
                              </div>
                            </div>
                          </article>
                        );
                      })}
                    </div>

                    {/* مقایسه فنی */}
                    <div className="mt-4">
                      <button onClick={() => setShowCompare((v) => !v)}
                        className="inline-flex items-center gap-2 rounded-full border border-hg-navy-900/20 px-4 py-2 text-[10px] font-black text-hg-navy-900 transition hover:bg-hg-cream"
                        aria-expanded={showCompare}>
                        <Table2 size={13} /> {showCompare ? "بستن مقایسه فنی" : "مقایسه فنی سه مدل"}
                      </button>
                      {showCompare && (
                        <div className="fade-up mt-3 overflow-x-auto rounded-2xl border border-hg-line">
                          <table className="w-full min-w-[560px] text-center text-[10px]">
                            <thead className="bg-hg-navy-900 text-hg-gold-300">
                              <tr>
                                <th className="p-3 text-right">مشخصه</th>
                                {results.map(({ product: p }) => (
                                  <th key={p.id} className="p-3">{p.fa}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-hg-line bg-white">
                              {(
                                [
                                  ["هسته تشک", (p: Product) => CORE_META[p.core].fa],
                                  ["سفتی (۵=خیلی سفت)", (p: Product) => toFa(p.firm)],
                                  ["حمایت ستون فقرات", (p: Product) => `${toFa(p.support)}/۵`],
                                  ["ایزولاسیون حرکت", (p: Product) => `${toFa(p.motion)}/۵`],
                                  ["سطح ارتوپدیک", (p: Product) => `${toFa(p.ortho)}/۵`],
                                  ["خنکی و تهویه", (p: Product) => `${toFa(p.cooling)}/۵`],
                                  ["گارانتی", (p: Product) => `${toFa(p.warranty)} سال`],
                                  ["شروع قیمت", (p: Product) => `${faMillion(p.startPrice)} ت`],
                                ] as Array<[string, (p: Product) => string]>
                              ).map(([label, fn]) => (
                                <tr key={label}>
                                  <td className="p-2.5 text-right font-bold text-hg-navy-800">{label}</td>
                                  {results.map(({ product: p }) => (
                                    <td key={p.id} className="p-2.5 font-bold text-hg-navy-900">{fn(p)}</td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>

                    {/* تکمیل‌کننده سبد: تاپر و محافظ */}
                    <div className="mt-4 grid gap-2 sm:grid-cols-2">
                      <a href="#accessories" className="group flex items-center gap-3 rounded-2xl border border-hg-gold-500/50 bg-gradient-to-l from-hg-gold-200/40 to-white p-3 transition hover:border-hg-gold-500">
                        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-hg-navy-900 text-hg-gold-400"><BedDouble size={20} strokeWidth={1.9} /></span>
                        <span>
                          <span className="block text-[9px] font-black text-hg-navy-900">تکمیل‌کننده پیشنهادی: تاپر هیگر</span>
                          <span className="mt-0.5 block text-[8px] leading-4 text-hg-navy-600">حس تخت نو بدون تعویض تشک — از ۱۳ میلیون تومان <span className="text-hg-gold-600 underline">جزئیات در همین صفحه</span></span>
                        </span>
                      </a>
                      <a href="#accessories" className="group flex items-center gap-3 rounded-2xl border border-hg-gold-500/50 bg-gradient-to-l from-hg-gold-200/40 to-white p-3 transition hover:border-hg-gold-500">
                        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-hg-gold-500 text-hg-navy-900"><ShieldCheck size={20} strokeWidth={1.9} /></span>
                        <span>
                          <span className="block text-[9px] font-black text-hg-navy-900">و محافظ تشک ضدآب هیگر</span>
                          <span className="mt-0.5 block text-[8px] leading-4 text-hg-navy-600">زره کامل در برابر عرق و مایعات — از ۳٫۳ میلیون تومان <span className="text-hg-gold-600 underline">جزئیات در همین صفحه</span></span>
                        </span>
                      </a>
                    </div>

                    <p className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-hg-cream p-3 text-[9px] leading-5 text-hg-navy-700">
                      قیمت‌های «از» و موجودی مربوط به فروشگاه higermattress.ir است. برای مشاوره و ثبت سفارش فوری:
                      <a href={STORE.telHref} className="inline-flex items-center gap-1 font-black text-hg-navy-900 underline decoration-hg-gold-500 decoration-2 underline-offset-2" dir="ltr">
                        <Phone size={11} /> {STORE.phone}
                      </a>
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ============ پنل کناری: بدن‌سنج زنده ============ */}
          <aside className="hidden lg:col-span-4 lg:block">
            <div className="sticky top-28 space-y-4">
              {/* کارت BMI */}
              <div className="overflow-hidden rounded-3xl border border-hg-navy-800 bg-hg-navy-900 text-hg-cream shadow-[0_24px_50px_rgba(7,15,29,0.35)]">
                <div className="flex items-center justify-between border-b border-white/10 bg-white/5 px-5 py-3">
                  <p className="flex items-center gap-2 text-xs font-black text-hg-gold-300"><BedDouble size={15} /> بدن‌سنج زنده شما</p>
                  <span className="rounded-full bg-hg-gold-500/15 px-2.5 py-1 text-[9px] font-bold text-hg-gold-300">بدون ثبت‌نام</span>
                </div>
                <div className="grid grid-cols-2 divide-x divide-x-reverse divide-white/10 p-5 text-center">
                  <div>
                    <p className="text-[10px] font-bold text-hg-cream/60">قد</p>
                    <p className="mt-1 text-3xl font-black text-white">{toFa(answers.height)}</p>
                    <p className="text-[9px] text-hg-cream/50">سانتی‌متر</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-hg-cream/60">وزن</p>
                    <p className="mt-1 text-3xl font-black text-white">{toFa(answers.weight)}</p>
                    <p className="text-[9px] text-hg-cream/50">کیلوگرم</p>
                  </div>
                </div>
                <div className="border-t border-white/10 px-5 py-4">
                  <div className="flex items-center justify-between text-[10px] font-bold text-hg-cream/70">
                    <span>BMI: <b className="text-hg-gold-300" dir="ltr">{bmi.toFixed(1)}</b></span>
                    <span>{bmiInfo.label}</span>
                  </div>
                  <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/10">
                    <div className="h-full rounded-full bg-gradient-to-l from-hg-gold-300 to-hg-gold-600 transition-all duration-300" style={{ width: `${bmiPct}%` }} />
                  </div>
                  {/* مروری بر انتخاب‌ها */}
                  <ul className="mt-4 space-y-1.5 text-[10px] leading-5">
                    {[
                      answers.age && ["سن", AGE_OPTIONS.find((a) => a.key === answers.age)?.label],
                      answers.position && ["وضعیت خواب", POSITION_OPTIONS.find((p) => p.key === answers.position)?.label],
                      answers.pain !== null && answers.pain && ["وضعیت جسم", PAIN_OPTIONS.find((p) => p.key === answers.pain)?.label],
                      answers.sleepers && ["همراه تخت", SLEEPER_OPTIONS.find((s) => s.key === answers.sleepers)?.label],
                      answers.budget && ["بودجه", BUDGET_OPTIONS.find((b) => b.key === answers.budget)?.label],
                      answers.priority && ["اولویت", PRIORITY_OPTIONS.find((p) => p.key === answers.priority)?.label],
                    ].filter(Boolean).map((row) => {
                      const [k, v] = row as [string, string | undefined];
                      return (
                        <li key={k} className="flex items-center justify-between gap-2 border-b border-white/5 pb-1.5">
                          <span className="text-hg-cream/50">{k}</span>
                          <span className="font-black text-hg-gold-200">{v}</span>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </div>

              {/* چرا اعتماد کنید */}
              <div className="rounded-3xl border border-hg-line bg-white p-5 shadow-sm">
                <div className="flex -space-x-2 space-x-reverse">
                  {["ع", "م", "س", "ر"].map((c, i) => (
                    <span key={i} className="grid h-9 w-9 place-items-center rounded-full border-2 border-white text-[11px] font-black text-hg-gold-300" style={{ background: ["#10243e", "#1f3e63", "#c8892a", "#2b4e77"][i] }}>{c}</span>
                  ))}
                  <span className="grid h-9 w-9 place-items-center rounded-full border-2 border-white bg-hg-gold-500 text-[9px] font-black text-hg-navy-900">+۲۰<br />هزار</span>
                </div>
                <p className="mt-3 text-[11px] font-black leading-5 text-hg-navy-900">بیش از ۲۰٬۰۰۰ راهنمای خرید موفق</p>
                <p className="mt-1 text-[9px] leading-5 text-hg-navy-600">نتیجه تشک‌سنج بر اساس استانداردهای ارگونومی ستون فقرات و بازخورد واقعی مشتریان هیگر از سال ۱۳۸۷ محاسبه می‌شود.</p>
                <a href={STORE.telHref} className="mt-3 flex items-center justify-center gap-2 rounded-xl border border-hg-navy-900/15 bg-hg-cream py-2.5 text-[10px] font-black text-hg-navy-900 transition hover:border-hg-gold-500">
                  <Phone size={13} /> مشاوره انسانی: {STORE.phone}
                </a>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}
