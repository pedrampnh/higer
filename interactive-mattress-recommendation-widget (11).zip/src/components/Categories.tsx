import type { CoreKey } from "../data";
import { CORE_META } from "../data";
import { faPrice, toFa } from "../utils/fa";
import { ArrowDownLeft, CircleCheck, Layers } from "lucide-react";

/* ================== دیاگرام‌های مقطع هسته (SVG دست‌ساز) ================== */

function BonnellDiagram() {
  const coil = (x: number) => (
    <g key={x} stroke="#e7b95c" strokeWidth="2" fill="none" strokeLinejoin="round">
      <path d={`M ${x} 22 L ${x + 4} 34 L ${x + 7} 44 L ${x + 10} 34 L ${x + 14} 22`} fill="rgba(217,161,59,0.12)" />
      <ellipse cx={x + 7} cy="22" rx="7.5" ry="2.6" fill="rgba(217,161,59,0.25)" />
      <ellipse cx={x + 7} cy="44" rx="7.5" ry="2.6" fill="rgba(217,161,59,0.25)" />
    </g>
  );
  return (
    <svg viewBox="0 0 220 96" className="h-full w-full" role="img" aria-label="مقطع فنر متصل">
      <line x1="6" y1="14" x2="214" y2="14" stroke="#f3d98b" strokeWidth="3" strokeLinecap="round" opacity="0.9" />
      <line x1="6" y1="56" x2="214" y2="56" stroke="#f3d98b" strokeWidth="3" strokeLinecap="round" opacity="0.9" />
      <line x1="6" y1="20" x2="214" y2="20" stroke="#d9a13b" strokeWidth="1.2" opacity="0.5" />
      <line x1="6" y1="50" x2="214" y2="50" stroke="#d9a13b" strokeWidth="1.2" opacity="0.5" />
      {[14, 46, 78, 110, 142, 174].map(coil)}
      <text x="110" y="76" textAnchor="middle" fill="#f3d98b" fontSize="10" fontWeight="700" opacity="0.85">BONELL — متصل یکپارچه</text>
    </svg>
  );
}

function PocketDiagram() {
  const unit = (x: number) => (
    <g key={x}>
      <rect x={x} y="16" width="26" height="40" rx="8" fill="rgba(243,217,139,0.10)" stroke="#e7b95c" strokeWidth="1.6" />
      <path d={`M ${x + 6} 24 C ${x + 20} 28, ${x + 6} 34, ${x + 20} 38 C ${x + 6} 42, ${x + 20} 46, ${x + 6} 50`} fill="none" stroke="#d9a13b" strokeWidth="1.8" />
    </g>
  );
  return (
    <svg viewBox="0 0 220 96" className="h-full w-full" role="img" aria-label="مقطع فنر منفصل پاکتی">
      <rect x="6" y="8" width="208" height="56" rx="6" fill="none" stroke="#f3d98b" strokeWidth="2" opacity="0.65" strokeDasharray="5 4" />
      {[14, 46, 78, 110, 142, 174].map(unit)}
      <text x="110" y="80" textAnchor="middle" fill="#f3d98b" fontSize="10" fontWeight="700" opacity="0.85">POCKET — هر فنر در جیب خود</text>
    </svg>
  );
}

function RebondDiagram() {
  const chips: Array<[number, number, number, string]> = [
    [18, 22, 6, "#d9a13b"], [38, 34, 5, "#f3d98b"], [52, 18, 4, "#8a6d3b"], [66, 40, 6, "#d9a13b"],
    [84, 24, 5, "#f3d98b"], [98, 44, 4, "#a86f1c"], [112, 20, 6, "#e7b95c"], [128, 36, 5, "#8a6d3b"],
    [142, 22, 4, "#d9a13b"], [158, 42, 6, "#f3d98b"], [172, 26, 5, "#a86f1c"], [192, 36, 4, "#d9a13b"],
    [30, 44, 4, "#a86f1c"], [76, 20, 3.5, "#e7b95c"], [122, 46, 3.5, "#d9a13b"], [182, 18, 3.5, "#f3d98b"],
  ];
  return (
    <svg viewBox="0 0 220 96" className="h-full w-full" role="img" aria-label="مقطع فوم ریباند">
      <rect x="8" y="12" width="204" height="44" rx="7" fill="rgba(138,109,59,0.28)" stroke="#e7b95c" strokeWidth="2" />
      {chips.map(([cx, cy, r, fill], i) => (
        <circle key={i} cx={cx} cy={cy} r={r} fill={fill} opacity="0.9" />
      ))}
      <text x="110" y="76" textAnchor="middle" fill="#f3d98b" fontSize="10" fontWeight="700" opacity="0.85">REBOND — تراشه فوم متراکم</text>
    </svg>
  );
}

function FoamDiagram() {
  return (
    <svg viewBox="0 0 220 96" className="h-full w-full" role="img" aria-label="مقطع فوم سنگین">
      <path d="M8 18 C 60 10, 150 26, 212 16 L 212 34 C 150 44, 60 28, 8 38 Z" fill="rgba(91,122,78,0.4)" stroke="#a8c793" strokeWidth="1.6" opacity="0.95" />
      <path d="M8 42 C 60 34, 150 50, 212 40 L 212 54 C 150 64, 60 48, 8 58 Z" fill="rgba(217,161,59,0.22)" stroke="#e7b95c" strokeWidth="1.6" />
      <path d="M8 62 C 60 54, 150 70, 212 60 L 212 66 C 150 76, 60 60, 8 70 Z" fill="rgba(243,217,139,0.14)" stroke="#f3d98b" strokeWidth="1.4" opacity="0.9" />
      <text x="110" y="86" textAnchor="middle" fill="#f3d98b" fontSize="10" fontWeight="700" opacity="0.85">DENSITY FOAM — لایه‌لایه ارتوپدیک</text>
    </svg>
  );
}

import type { ReactElement } from "react";

const DIAGRAMS: Record<CoreKey, () => ReactElement> = {
  bonnell: BonnellDiagram,
  pocket: PocketDiagram,
  rebond: RebondDiagram,
  foam: FoamDiagram,
};

const ORDER: CoreKey[] = ["bonnell", "pocket", "rebond", "foam"];

export default function Categories({ onSelect }: { onSelect: (core: CoreKey) => void }) {
  return (
    <section id="hast-ha" className="paper-texture py-16 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* سربرگ */}
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-2xl">
            <p className="inline-flex items-center gap-2 rounded-full border border-hg-gold-500/50 bg-white/70 px-4 py-1.5 text-[10px] font-bold text-hg-gold-600">
              <Layers size={12} /> ۴ دسته اصلی هسته تشک
            </p>
            <h2 className="mt-4 text-3xl font-black leading-snug text-hg-navy-900 sm:text-4xl">
              قلب تشک را بشناس؛ <span className="gold-text">بقیه‌اش خودش می‌آید</span>
            </h2>
            <p className="mt-3 text-sm leading-7 text-hg-navy-700">
              هسته تعیین می‌کند تشک چه حسی دارد و چند سال دوام می‌آورد. هیگر در هر ۴ تکنولوژی روز دنیا
              محصول تخصصی تولید می‌کند؛ روی هر کارت بزنید تا همان دسته در فروشگاه فیلتر شود.
            </p>
          </div>
          <a href="#tashik-sanj" className="group inline-flex items-center gap-2 rounded-full bg-hg-navy-900 px-5 py-3 text-xs font-black text-hg-gold-300 transition hover:bg-hg-navy-800">
            نمی‌دانم کدام؟ تشک‌سنج کمکم کن
            <ArrowDownLeft size={15} className="transition-transform group-hover:-translate-x-1 group-hover:translate-y-1" />
          </a>
        </div>

        {/* کارت‌ها */}
        <div className="mt-10 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {ORDER.map((key, i) => {
            const meta = CORE_META[key];
            const Diagram = DIAGRAMS[key];
            return (
              <article key={key}
                className="light-card group flex flex-col overflow-hidden rounded-3xl"
                style={{ animationDelay: `${i * 90}ms` }}>
                {/* ناحیه دیاگرام */}
                <div className="relative h-36 overflow-hidden bg-hg-navy-900 p-4">
                  <span aria-hidden="true" className="absolute right-3 top-2 text-5xl font-black text-white/5 select-none">
                    {toFa(i + 1).padStart(2, "۰")}
                  </span>
                  <div className="h-full transition-transform duration-500 ease-out group-hover:scale-[1.06]">
                    <Diagram />
                  </div>
                  <span className="absolute left-3 top-3 rounded-full border border-hg-gold-500/40 bg-hg-gold-500/10 px-2.5 py-1 text-[8px] font-black tracking-widest text-hg-gold-300" dir="ltr">
                    {meta.en.toUpperCase()}
                  </span>
                </div>
                {/* محتوا */}
                <div className="flex flex-1 flex-col p-5">
                  <h3 className="text-xl font-black text-hg-navy-900">{meta.fa}</h3>
                  <p className="mt-2 text-[11px] leading-6 text-hg-navy-700">{meta.short}</p>
                  <p className="mt-3 flex items-start gap-1.5 text-[10px] font-bold leading-5 text-hg-navy-800">
                    <CircleCheck size={13} strokeWidth={2.5} className="mt-0.5 shrink-0 text-emerald-600" />
                    مناسب برای: {meta.idealFor}
                  </p>
                  <p className="mt-2 text-[10px] leading-5 text-hg-navy-600">
                    <span className="font-black text-hg-navy-800">مدل‌های شاخص: </span>{meta.models}
                  </p>
                  <div className="mt-auto flex items-center justify-between gap-2 border-t border-hg-line pt-4">
                    <div>
                      <p className="text-[8px] font-bold text-hg-navy-600">شروع قیمت</p>
                      <p className="text-xs font-black text-hg-navy-900" dir="ltr">{faPrice(meta.priceFrom)}</p>
                    </div>
                    <button onClick={() => onSelect(key)}
                      className="rounded-full border border-hg-navy-900 bg-hg-navy-900 px-4 py-2 text-[10px] font-black text-hg-gold-300 transition group-hover:bg-hg-navy-800 hover:!bg-hg-gold-500 hover:!text-hg-navy-900 hover:!border-hg-gold-500">
                      مشاهده مدل‌ها
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
