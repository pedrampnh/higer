/** لوگوی بازطراحی‌شده هیگر — مونوگرام H طلایی + واژه‌نگار انگلیسی و فارسی */
export default function Logo({ dark = true }: { dark?: boolean }) {
  return (
    <a href="#top" className="group flex items-center gap-3 select-none" aria-label="تشک هیگر — صفحه اصلی">
      {/* مونوگرام */}
      <span className="relative grid place-items-center">
        <svg width="52" height="52" viewBox="0 0 64 64" role="img" aria-hidden="true" className="drop-shadow-[0_6px_16px_rgba(217,161,59,0.35)] transition-transform duration-300 group-hover:scale-105">
          <rect x="2" y="2" width="60" height="60" rx="15" fill={dark ? "#10243E" : "#10243E"} stroke="#D9A13B" strokeWidth="2.5" />
          <path d="M19 45V19h6.4v10.6h13.2V19H45v26h-6.4V34.4H25.4V45H19z" fill="#D9A13B" />
          <rect x="24" y="50" width="16" height="2.6" rx="1.3" fill="#D9A13B" opacity="0.85" />
        </svg>
      </span>
      {/* واژه‌نگار */}
      <span className="flex flex-col leading-none">
        <span
          className="text-[1.72rem] font-black tracking-[0.14em]"
          style={{
            fontFamily: "'IRANSans','Vazirmatn',sans-serif",
            color: dark ? "#10243E" : "#FAF7EF",
          }}
        >
          HIGER
          <span className="text-hg-gold-500">.</span>
        </span>
        <span className={`mt-1 text-[11px] font-bold tracking-wide ${dark ? "text-hg-navy-600" : "text-hg-gold-300"}`}>
          تشک هیگر — خواب استاندارد
        </span>
      </span>
    </a>
  );
}
