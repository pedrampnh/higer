import { useEffect, useMemo, useState } from "react";
import { PRODUCTS, CORE_META, shopSearchUrl, type CoreKey } from "../data";
import { faPrice, toFa } from "../utils/fa";
import { ShieldCheck, ExternalLink, ArrowUpDown, BadgePercent } from "lucide-react";

export type CoreFilter = CoreKey | "all";

function MattressArt({ core }: { core: CoreKey }) {
  const tint = CORE_META[core].hue;
  return (
    <svg viewBox="0 0 200 96" className="h-full w-full" role="img" aria-label="تصویر شماتیک تشک">
      {/* سایه زمین */}
      <ellipse cx="100" cy="88" rx="86" ry="6" fill="rgba(16,36,62,0.18)" />
      {/* لایه بالشتک (pillow-top) */}
      <path d="M14 44 C 60 30, 140 30, 186 44 L 186 56 C 140 46, 60 46, 14 56 Z" fill="#f7efdd" stroke="#10243e" strokeWidth="2" />
      {/* بدنه */}
      <path d="M14 56 L 186 56 L 186 72 C 140 62, 60 62, 14 72 Z" fill="#fffdf4" stroke="#10243e" strokeWidth="2" />
      {/* نوار وسط با رنگ هسته */}
      <path d="M14 63.4 L 186 63.4" stroke={tint} strokeWidth="3.4" opacity="0.9" />
      {/* کوک‌ها */}
      {[48, 84, 116, 152].map((x) => (
        <circle key={x} cx={x} cy={50} r="1.7" fill="#10243e" opacity="0.55" />
      ))}
      {/* برچسب برند */}
      <rect x="88" y="58" width="24" height="7" rx="2" fill="#10243e" />
      <rect x="91" y="60.4" width="18" height="2.2" rx="1.1" fill="#d9a13b" />
    </svg>
  );
}

const FILTERS: Array<{ key: CoreFilter; label: string }> = [
  { key: "all", label: "همه مدل‌ها" },
  { key: "bonnell", label: "فنر متصل" },
  { key: "pocket", label: "فنر منفصل" },
  { key: "rebond", label: "ریباند" },
  { key: "foam", label: "فوم سنگین" },
];

export default function Products({ selected, onChange }: { selected: CoreFilter; onChange: (c: CoreFilter) => void }) {
  const [sort, setSort] = useState<"featured" | "asc" | "desc">("featured");
  const [pulse, setPulse] = useState(0);

  useEffect(() => setPulse((p) => p + 1), [selected, sort]);

  const items = useMemo(() => {
    let list = PRODUCTS.filter((p) => selected === "all" || p.core === selected);
    if (sort === "asc") list = [...list].sort((a, b) => a.startPrice - b.startPrice);
    else if (sort === "desc") list = [...list].sort((a, b) => b.startPrice - a.startPrice);
    return list;
  }, [selected, sort]);

  const countFor = (k: CoreFilter) => (k === "all" ? PRODUCTS.length : PRODUCTS.filter((p) => p.core === k).length);

  return (
    <section id="products" className="bg-hg-cream py-16 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* سربرگ */}
        <div className="flex flex-wrap items-end justify-between gap-5">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-hg-gold-500/50 bg-white/70 px-4 py-1.5 text-[10px] font-bold text-hg-gold-600">
              <BadgePercent size={12} /> قیمت‌های درب کارخانه
            </p>
            <h2 className="mt-4 text-3xl font-black text-hg-navy-900 sm:text-4xl">محصولات شاخص <span className="gold-text">هیگر</span></h2>
            <p className="mt-2 max-w-xl text-sm leading-7 text-hg-navy-700">
              {toFa(items.length)} مدل — مشخصات فنی و قیمت «از» مستقیم از فروشگاه higermattress.ir. روی هر مدل بزنید تا مستقیم در فروشگاه باز شود.
            </p>
          </div>
          {/* مرتب‌سازی */}
          <label className="flex items-center gap-2 rounded-2xl border border-hg-line bg-white px-4 py-2.5 text-[11px] font-bold text-hg-navy-800 shadow-sm">
            <ArrowUpDown size={14} className="text-hg-gold-600" />
            <select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} className="bg-transparent outline-none" aria-label="مرتب‌سازی محصولات">
              <option value="featured">پیشنهاد هیگر</option>
              <option value="asc">ارزان‌ترین اول</option>
              <option value="desc">گران‌ترین اول</option>
            </select>
          </label>
        </div>

        {/* فیلتر هسته‌ها */}
        <div className="mt-6 flex flex-wrap items-center gap-2" role="tablist" aria-label="فیلتر بر اساس هسته تشک">
          {FILTERS.map(({ key, label }) => {
            const active = selected === key;
            return (
              <button key={key} role="tab" aria-selected={active} onClick={() => onChange(key)}
                className={`group flex items-center gap-2 rounded-full border px-4 py-2 text-[11px] font-black transition-all ${
                  active
                    ? "border-hg-navy-900 bg-hg-navy-900 text-hg-gold-300 shadow-[0_10px_24px_rgba(16,36,62,0.35)]"
                    : "border-hg-line bg-white text-hg-navy-800 hover:border-hg-gold-500"
                }`}>
                {key !== "all" && <span className="h-2 w-2 rounded-full" style={{ background: CORE_META[key].hue }} />}
                {label}
                <span className={`rounded-full px-1.5 py-0.5 text-[8px] ${active ? "bg-hg-gold-500 text-hg-navy-900" : "bg-hg-paper text-hg-navy-700"}`}>{toFa(countFor(key))}</span>
              </button>
            );
          })}
        </div>

        {/* گرید محصولات */}
        <div key={pulse} className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {items.map((p) => {
            const core = CORE_META[p.core];
            return (
              <article key={p.id} className="light-card flex flex-col overflow-hidden rounded-2xl">
                {/* تصویر شماتیک */}
                <div className="relative h-28 bg-gradient-to-bl from-hg-navy-800 via-hg-navy-900 to-hg-navy-950 p-3">
                  {p.badge && (
                    <span className="absolute right-2 top-2 z-10 rounded-full bg-hg-gold-500 px-2.5 py-1 text-[8px] font-black text-hg-navy-900 shadow">{p.badge}</span>
                  )}
                  <MattressArt core={p.core} />
                </div>
                {/* بدنه */}
                <div className="flex flex-1 flex-col p-4">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-black text-hg-navy-900">{p.fa}</h3>
                    <span className="rounded-full bg-hg-paper px-2 py-0.5 text-[8px] font-black text-hg-navy-700" dir="ltr">{p.en}</span>
                  </div>
                  <p className="mt-1.5 flex items-center gap-1.5 text-[9px] font-bold text-hg-navy-700">
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: core.hue }} />
                    هسته {core.fa}
                    <span className="text-hg-line">|</span>
                    گارانتی {toFa(p.warranty)} ساله
                  </p>
                  {/* سفتی */}
                  <div className="mt-2.5 flex items-center justify-between">
                    <span className="text-[9px] font-bold text-hg-navy-600">سفتی سطح</span>
                    <span className="flex items-center gap-1" dir="ltr" aria-label={`سفتی ${p.firm} از ۵`}>
                      {[1, 2, 3, 4, 5].map((d) => (
                        <span key={d} className={`h-1.5 w-4 rounded-full ${d <= p.firm ? "bg-hg-gold-500" : "bg-hg-line"}`} />
                      ))}
                    </span>
                  </div>
                  <p className="mt-2 line-clamp-2 min-h-[28px] text-[9px] leading-5 text-hg-navy-600">{p.blurb}</p>
                  {/* قیمت و CTA */}
                  <div className="mt-auto flex items-end justify-between gap-2 border-t border-hg-line pt-3">
                    <div>
                      <p className="text-[8px] font-bold text-hg-navy-600">شروع قیمت</p>
                      <p className="text-[11px] font-black leading-4 text-hg-navy-900" dir="ltr">{faPrice(p.startPrice)}</p>
                    </div>
                    <a href={shopSearchUrl(p.fa)} target="_blank" rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 rounded-full border border-hg-navy-900 px-3 py-1.5 text-[9px] font-black text-hg-navy-900 transition hover:bg-hg-navy-900 hover:text-hg-gold-300">
                      سفارش و قیمت <ExternalLink size={10} />
                    </a>
                  </div>
                  <p className="mt-2 flex items-center gap-1 text-[8px] font-bold text-emerald-700"><ShieldCheck size={10} /> گارانتی شرکتی + پرداخت در محل</p>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
