import { useEffect, useState } from "react";
import { Menu, X, Phone, ShieldCheck, Truck, BadgePercent, ChevronDown } from "lucide-react";
import Logo from "./Logo";
import { STORE } from "../data";

const NAV = [
  { label: "تشک‌سنج هوشمند", href: "#tashik-sanj" },
  { label: "۴ هسته تشک", href: "#hast-ha" },
  { label: "محصولات", href: "#products" },
  { label: "تاپر و محافظ تشک", href: "#accessories" },
  { label: "گارانتی و ارسال", href: "#faq" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="sticky top-0 z-50">
      {/* ===== نوار بالایی اعتماد ===== */}
      <div className="midnight text-[11px] text-hg-gold-200/90">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-1.5 sm:px-6">
          <div className="flex items-center gap-4">
            <span className="hidden items-center gap-1.5 sm:flex">
              <ShieldCheck size={13} strokeWidth={2.4} className="text-hg-gold-400" />
              گارانتی شرکتی ۵ تا ۱۰ سال
            </span>
            <span className="hidden items-center gap-1.5 md:flex">
              <Truck size={13} strokeWidth={2.4} className="text-hg-gold-400" />
              ارسال مستقیم از کارخانه
            </span>
            <span className="hidden items-center gap-1.5 lg:flex">
              <BadgePercent size={13} strokeWidth={2.4} className="text-hg-gold-400" />
              قیمت کارخانه بدون واسطه
            </span>
          </div>
          <a href={STORE.telHref} className="flex items-center gap-1.5 font-bold text-hg-gold-300 transition-colors hover:text-white" dir="ltr">
            <Phone size={12} strokeWidth={2.6} />
            {STORE.phone}
          </a>
        </div>
      </div>

      {/* ===== هدر اصلی ===== */}
      <div
        className={`border-b transition-all duration-300 ${
          scrolled ? "border-hg-line bg-hg-cream/90 shadow-[0_8px_30px_rgba(16,36,62,0.12)] backdrop-blur-xl" : "border-transparent bg-hg-cream"
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <Logo dark />

          <nav className="hidden items-center gap-7 text-[13px] font-bold text-hg-navy-800 lg:flex" aria-label="منوی اصلی">
            {NAV.map((item) => (
              <a key={item.href} href={item.href} className="group relative py-2 transition-colors hover:text-hg-navy-950">
                {item.label}
                <span className="absolute bottom-0 right-0 h-[2.5px] w-0 rounded-full bg-hg-gold-500 transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a href="#tashik-sanj" className="btn-gold hidden px-5 py-2.5 text-xs sm:inline-flex">
              شروع تشک‌سنج
              <span className="pulse-dot inline-block h-2 w-2 rounded-full bg-hg-navy-900" />
            </a>
            <button
              onClick={() => setOpen((v) => !v)}
              className="grid h-11 w-11 place-items-center rounded-xl border border-hg-line bg-white/70 text-hg-navy-900 lg:hidden"
              aria-label={open ? "بستن منو" : "باز کردن منو"}
              aria-expanded={open}
            >
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* ===== منوی موبایل ===== */}
        {open && (
          <div className="border-t border-hg-line bg-hg-cream/97 backdrop-blur-xl lg:hidden">
            <div className="mx-auto max-w-7xl space-y-1 px-4 py-4 sm:px-6">
              {NAV.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-between rounded-xl px-4 py-3 text-sm font-bold text-hg-navy-800 transition-colors hover:bg-hg-gold-200/50"
                >
                  {item.label}
                  <ChevronDown size={16} className="-rotate-90 text-hg-gold-600" />
                </a>
              ))}
              <a href={STORE.telHref} className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-hg-navy-900 px-4 py-3 text-sm font-bold text-hg-gold-300">
                <Phone size={16} /> مشاوره تلفنی رایگان: {STORE.phone}
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
