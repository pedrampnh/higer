import { useCallback, useEffect, useState } from "react";
import { Code2, Copy, Check, Download, FileCode2, Globe, ListOrdered, Blocks } from "lucide-react";

const IFRAME_SNIPPET = `<iframe
  src="https://higermattress.ir/wp-content/uploads/higer-widget.html"
  width="100%" height="860"
  style="border:0;border-radius:20px;box-shadow:0 24px 60px rgba(16,36,62,.22)"
  loading="lazy" title="تشک‌سنج هوشمند هیگر"></iframe>`;

const ELEMENTOR_STEPS = [
  "دکمه «دانلود فایل ویجت» را بزنید — یک فایل HTML مستقل و بدون وابستگی است.",
  "گزینه ۱ (پیشنهادی): فایل را در هاست خود آپلود کنید (مثلاً wp-content/uploads) و آدرس را در کد ایفریم بالا جایگذاری کنید.",
  "گزینه ۲ (مستقیم): در المنتور یک ویجت «HTML» باز کنید و با دکمه «کپی کل کد ویجت»، کل محتوای فایل را داخل همان ویجت جایگذاری کنید — بدون نیاز به آپلود.",
  "در هر دو حالت: ویجت را هرجای صفحه که بخواهید (هوم، محصول، گارانتی) قرار دهید؛ کاملاً مستقل و ریسپانسیو است.",
];

export default function WidgetSection() {
  const [copied, setCopied] = useState<"iframe" | "full" | null>(null);
  const [fullCode, setFullCode] = useState<string>("");
  const [loadState, setLoadState] = useState<"idle" | "loading" | "ready">("idle");

  const copy = useCallback(async (text: string, kind: "iframe" | "full") => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(kind);
      window.setTimeout(() => setCopied(null), 2200);
    } catch {
      /* clipboard در دسترس نیست */
    }
  }, []);

  const loadFullCode = useCallback(async () => {
    setLoadState("loading");
    try {
      const res = await fetch("higer-widget.html");
      const text = await res.text();
      setFullCode(text);
      setLoadState("ready");
      return text;
    } catch {
      setLoadState("idle");
      return "";
    }
  }, []);

  const copyFull = async () => {
    const text = fullCode || (await loadFullCode());
    if (text) await copy(text, "full");
  };

  // پیش‌بارگذاری کد کامل در پس‌زمینه
  useEffect(() => {
    loadFullCode();
  }, [loadFullCode]);

  return (
    <section id="widget" className="midnight relative overflow-hidden py-16 text-hg-cream lg:py-24">
      <div className="grid-lines absolute inset-0 opacity-60" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-12">
          {/* ===== ستون توضیحات ===== */}
          <div className="lg:col-span-5">
            <p className="inline-flex items-center gap-2 rounded-full border border-hg-gold-500/40 bg-hg-gold-500/10 px-4 py-1.5 text-[10px] font-bold text-hg-gold-300">
              <Blocks size={12} /> نصب سریع روی هر صفحه
            </p>
            <h2 className="mt-4 text-3xl font-black leading-snug sm:text-4xl">
              این تشک‌سنج را <span className="gold-text">هرجای سایتت</span> بگذار
            </h2>
            <p className="mt-3 text-sm leading-8 text-hg-gold-200/85">
              یک فایل HTML مستقل (بدون نیاز به کتابخانه و اینترنت اضافه) آماده شده است؛ فونت IRANSans،
              رنگ‌بندی لوگوی هیگر، RTL کامل، ۸ سؤال و خروجی ۳ مدل برتر — دقیقاً مثل همین صفحه.
              آن را در ویجت «HTML» المنتور (یا هر صفحه‌ساز دیگری) جایگذاری کنید.
            </p>

            <ol className="mt-6 space-y-3">
              {ELEMENTOR_STEPS.map((s, i) => (
                <li key={i} className="flex items-start gap-3 text-[11px] leading-6 text-hg-cream/85">
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full border border-hg-gold-500/50 bg-hg-gold-500/15 text-[10px] font-black text-hg-gold-300">{i + 1}</span>
                  {s}
                </li>
              ))}
            </ol>

            <div className="mt-6 flex flex-wrap gap-3">
              <a href="higer-widget.html" download="higer-widget.html" className="btn-gold px-6 py-3.5 text-xs">
                <Download size={16} strokeWidth={2.5} />
                دانلود فایل ویجت (higer-widget.html)
              </a>
              <a href="higer-widget.html" target="_blank" rel="noopener noreferrer" className="btn-outline px-6 py-3.5 text-xs">
                <Globe size={16} strokeWidth={2.2} />
                پیش‌نمایش زنده ویجت
              </a>
            </div>

            {/* ===== صفحه هوم کامل برای WPCode ===== */}
            <div className="mt-5 rounded-2xl border border-white/10 bg-white/5 p-4">
              <p className="flex items-center gap-2 text-[11px] font-black text-hg-cream/90">
                <FileCode2 size={14} className="text-hg-gold-400" />
                صفحه هوم کامل — برای اسنیپت PHP در WPCode
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <a href="higer-home-host-images.php" download="higer-home-host-images.php" className="btn-gold px-4 py-2.5 text-[11px]">
                  <Download size={14} strokeWidth={2.5} />
                  اسنیپت PHP — عکس‌ها از هاست
                </a>
                <a href="higer-home.php" download="higer-home.php" className="btn-outline px-4 py-2.5 text-[11px]">
                  <Download size={14} strokeWidth={2.2} />
                  اسنیپت PHP — عکس‌های داخلی
                </a>
                <a href="higer-home.html" download="higer-home.html" className="btn-outline px-4 py-2.5 text-[11px]">
                  <Download size={14} strokeWidth={2.2} />
                  اسنیپت HTML
                </a>
              </div>
              <p className="mt-3 text-[10px] leading-6 text-hg-cream/60">
                در WPCode نوع «PHP Snippet» و Insert Method را روی «Shortcode» بگذارید و شورت‌کد را در صفحه هوم قرار دهید. فقط یکی از دو نسخه PHP را فعال کنید.
                <br />
                نسخه «عکس‌ها از هاست» بدون هیچ ویرایشی کار می‌کند: دو عکس را با نام‌های
                <b dir="ltr" className="text-hg-gold-300"> higer-hero.webp </b>،
                <b dir="ltr" className="text-hg-gold-300"> higer-factory.webp </b> و
                <b dir="ltr" className="text-hg-gold-300"> higer-topper.webp </b>
                در «رسانه» وردپرس آپلود کنید تا خودش پیدایشان کند.
              </p>
              <div className="mt-3 flex flex-wrap items-center gap-3 text-[10px] font-bold text-hg-gold-200/80">
                <span>عکس‌های آماده با همین نام‌ها:</span>
                <a href="higer-images/higer-hero.webp" download className="underline decoration-hg-gold-500/50 underline-offset-4 transition hover:text-hg-gold-300" dir="ltr">
                  higer-hero.webp
                </a>
                <a href="higer-images/higer-factory.webp" download className="underline decoration-hg-gold-500/50 underline-offset-4 transition hover:text-hg-gold-300" dir="ltr">
                  higer-factory.webp
                </a>
                <a href="higer-images/higer-topper.webp" download className="underline decoration-hg-gold-500/50 underline-offset-4 transition hover:text-hg-gold-300" dir="ltr">
                  higer-topper.webp
                </a>
              </div>
            </div>
          </div>

          {/* ===== ستون کد ===== */}
          <div className="lg:col-span-7">
            <div className="overflow-hidden rounded-2xl border border-white/10 bg-[#0b1626]/90 shadow-[0_30px_70px_rgba(0,0,0,0.45)] backdrop-blur">
              {/* نوار پنجره */}
              <div className="flex items-center justify-between border-b border-white/10 bg-white/5 px-4 py-3">
                <div className="flex items-center gap-2">
                  <span className="h-3 w-3 rounded-full bg-red-400/80" />
                  <span className="h-3 w-3 rounded-full bg-amber-400/80" />
                  <span className="h-3 w-3 rounded-full bg-emerald-400/80" />
                  <span className="mr-3 flex items-center gap-1.5 text-[10px] font-bold text-hg-cream/60"><FileCode2 size={12} /> higer-widget — نحوه درج در سایت</span>
                </div>
                <button
                  onClick={() => copy(IFRAME_SNIPPET, "iframe")}
                  className="flex items-center gap-1.5 rounded-lg border border-hg-gold-500/40 bg-hg-gold-500/10 px-3 py-1.5 text-[10px] font-bold text-hg-gold-300 transition hover:bg-hg-gold-500/20"
                >
                  {copied === "iframe" ? <Check size={12} /> : <Copy size={12} />}
                  {copied === "iframe" ? "کپی شد!" : "کپی کد ایفریم"}
                </button>
              </div>
              <pre className="code-scroll overflow-x-auto p-5 text-left text-[11px] leading-6" dir="ltr" style={{ fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" }}>
                <code>
                  <span className="text-slate-500">{"<!-- تشک‌سنج هیگر را با این خط هرجایی درج کنید -->"}</span>{"\n"}
                  <span className="text-hg-gold-300">{"<iframe\n  src="}</span>
                  <span className="text-emerald-300">{'"https://higermattress.ir/wp-content/uploads/higer-widget.html"'}</span>{"\n"}
                  <span className="text-hg-gold-300">{"  width="}</span><span className="text-sky-300">"100%"</span> <span className="text-hg-gold-300">{"height="}</span><span className="text-sky-300">"860"</span>{"\n"}
                  <span className="text-hg-gold-300">{"  style="}</span><span className="text-sky-300">"border:0;border-radius:20px"</span>{"\n"}
                  <span className="text-hg-gold-300">{"  loading="}</span><span className="text-sky-300">"lazy"</span> <span className="text-hg-gold-300">{"title="}</span><span className="text-sky-300">"تشک‌سنج هیگر"</span>{"\n"}
                  <span className="text-hg-gold-300">{"></iframe>"}</span>
                </code>
              </pre>

              {/* کپی مستقیم کل کد */}
              <div className="border-t border-white/10 p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <ListOrdered size={15} className="text-hg-gold-400" />
                    <p className="text-[11px] font-black text-hg-cream/90">حالت بدون آپلود: کل کد ویجت را مستقیم در ویجت HTML المنتور بچسبانید</p>
                  </div>
                  <button
                    onClick={copyFull}
                    disabled={loadState === "loading"}
                    className="flex items-center gap-1.5 rounded-lg bg-hg-gold-500 px-4 py-2 text-[10px] font-black text-hg-navy-900 transition hover:bg-hg-gold-400 disabled:opacity-60"
                  >
                    {copied === "full" ? <Check size={12} /> : <Copy size={12} />}
                    {copied === "full" ? "کل کد کپی شد!" : loadState === "loading" ? "در حال آماده‌سازی…" : "کپی کل کد ویجت"}
                  </button>
                </div>
                <details className="group mt-3 rounded-xl border border-white/10 bg-black/30">
                  <summary className="flex cursor-pointer items-center gap-2 px-4 py-2.5 text-[10px] font-bold text-hg-cream/70 transition hover:text-hg-gold-300">
                    <Code2 size={12} />
                    مشاهده پیش‌نمایش کد ({fullCode ? `${Math.round(fullCode.length / 1024)} کیلوبایت` : "…"})
                  </summary>
                  <pre dir="ltr" className="code-scroll max-h-64 overflow-auto border-t border-white/10 p-4 text-left text-[9px] leading-5 text-slate-400" style={{ fontFamily: "ui-monospace, Menlo, monospace" }}>
                    {fullCode ? fullCode.slice(0, 6000) + (fullCode.length > 6000 ? "\n\n/* … ادامه کد — با دکمه «کپی کل کد» همه‌اش کپی می‌شود … */" : "") : "در حال بارگذاری کد…"}
                  </pre>
                </details>
              </div>
            </div>

            <p className="mt-4 text-center text-[10px] leading-6 text-hg-cream/55">
              ویجت بدون هیچ ردیاب یا وابستگی بیرونی کار می‌کند؛ تنها منبع بیرونی، فونت IRANSans از CDN است.
              <br />
              برای تغییر متن دکمه‌ها یا لینک فروشگاه، کافیست فایل را با یک ویرایشگر متن باز کنید.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
