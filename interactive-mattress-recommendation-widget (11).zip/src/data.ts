/* =====================================================================
   کاتالوگ واقعی تشک هیگر — برگرفته از فروشگاه higermattress.ir
   (حدود قیمت «از» = کمترین قیمت رنج فروشگاه / دی‌ماه ۱۴۰۴)
   دسته‌بندی‌ها: فنر متصل | فنر منفصل | ریباند | فوم سنگین
   ===================================================================== */

export type CoreKey = "bonnell" | "pocket" | "rebond" | "foam";

export interface Product {
  id: string;
  fa: string;        // نام فارسی
  en: string;        // نام لاتین مدل
  core: CoreKey;
  startPrice: number; // تومان (حداقل قیمت فروشگاه)
  firm: number;    // ۱ خیلی نرم تا ۵ خیلی سفت
  support: number; // ۱ تا ۵ حمایت از ستون فقرات
  motion: number;  // ۱ تا ۵ ایزولاسیون حرکت (بالاتر = کمتر منتقل می‌شود)
  cooling: number; // ۱ تا ۵ تهویه/خنکی
  ortho: number;   // ۱ تا ۵ سطح ارتوپدیک
  idealMin: number;// وزن ایده‌آل (کیلوگرم)
  idealMax: number;
  warranty: number;   // سال گارانتی
  badge?: string;
  positions: Array<"back" | "side" | "stomach" | "combo">;
  blurb: string;
}

export const CORE_META: Record<
  CoreKey,
  {
    fa: string;
    en: string;
    short: string;
    idealFor: string;
    models: string;
    priceFrom: number;
    hue: string;
  }
> = {
  bonnell: {
    fa: "فنر متصل",
    en: "Bonnell Spring",
    short: "سطح سفت و یکپارچه، حمایت کلاسیک کمر؛ شبکه فولادی یکپارچه اقتصادی و بادوام.",
    idealFor: "کمردرد خفیف، خواب پشت/شکم، بودجه اقتصادی",
    models: "کانگورو، اکونومیک، روکسانا، همر و تراست",
    priceFrom: 11_200_000,
    hue: "#d9a13b",
  },
  pocket: {
    fa: "فنر منفصل",
    en: "Pocket Spring",
    short: "هر فنر در جیب پارچه‌ای مستقل است؛ لرزش غلت‌زدن دو نفر به هم منتقل نمی‌شود.",
    idealFor: "تخت دونفره، خواب سبک‌خواب‌ها، پربازده‌ترین ایزولاسیون حرکت",
    models: "الدورادو سوپرلوکس، آمستردام، آواتار و زستر",
    priceFrom: 65_000_000,
    hue: "#3a6189",
  },
  rebond: {
    fa: "ریباند (بدون فنر)",
    en: "Rebounded Foam",
    short: "فوم متراکم ارتوپدیک بدون فلز و بی‌صدا؛ توزیع یکنواخت وزن و مهار گودافتادگی.",
    idealFor: "دیسک و مهره‌های کمر، دردهای شدید ستون فقرات، وزن بالا",
    models: "راینو، رومانس، کلایمکس و هیپو",
    priceFrom: 54_000_000,
    hue: "#8a6d3b",
  },
  foam: {
    fa: "فوم سنگین (طبی)",
    en: "High-Density Foam",
    short: "هسته فوم چگالی بالا؛ سبک، کاملاً بی‌صدا و بدون لرزش، با حس آرام و ارگونومیک.",
    idealFor: "آپارتمان‌های نورسیده، سبک‌خواب‌ها، درخواست سطح متوسط تا سفت",
    models: "نایت، کوئین، اومئا، آوینا، هلسا و پلژر",
    priceFrom: 14_600_000,
    hue: "#5b7a4e",
  },
};

export const PRODUCTS: Product[] = [
  /* ---------- فنر متصل ---------- */
  {
    id: "kangaroo", fa: "کانگورو", en: "Kangaroo", core: "bonnell",
    startPrice: 11_200_000, firm: 4, support: 4, motion: 2, cooling: 4, ortho: 2,
    idealMin: 55, idealMax: 110, warranty: 5, badge: "پرفروش و اقتصادی",
    positions: ["back", "stomach"],
    blurb: "فنر بونل تقویت‌شده با روکش گردباف ضدحساسیت؛ انتخاب اول اقتصادی.",
  },
  {
    id: "economic", fa: "اکونومیک", en: "Economic", core: "bonnell",
    startPrice: 14_600_000, firm: 4, support: 4, motion: 2, cooling: 4, ortho: 2,
    idealMin: 55, idealMax: 115, warranty: 5,
    positions: ["back", "stomach", "combo"],
    blurb: "محکم و قابل‌اعتماد برای استفاده روزمره و خواب پشت.",
  },
  {
    id: "Roxana", fa: "روکسانا", en: "Roxana", core: "bonnell",
    startPrice: 28_000_000, firm: 3, support: 4, motion: 2, cooling: 3, ortho: 2,
    idealMin: 45, idealMax: 100, warranty: 7,
    positions: ["back", "combo", "side"],
    blurb: "تعادل نرمی و سفتی؛ بهترین فروش فنر متصل برای خانواده‌ها.",
  },
  {
    id: "Roxana+", fa: "روکسانا پلاس", en: "Roxana+", core: "bonnell",
    startPrice: 24_000_000, firm: 4, support: 4, motion: 2, cooling: 3, ortho: 3,
    idealMin: 60, idealMax: 115, warranty: 7,
    positions: ["back", "stomach"],
    blurb: "نسخه تقویت‌شده روکسانا با حمایت بیشتر کمر و مهره‌ها.",
  },
  {
    id: "Hammer", fa: "همر", en: "Hammer", core: "bonnell",
    startPrice: 44_000_000, firm: 5, support: 5, motion: 2, cooling: 3, ortho: 3,
    idealMin: 75, idealMax: 135, warranty: 8, badge: "ویژه سنگین‌وزن‌ها",
    positions: ["back", "stomach"],
    blurb: "اسکلت فنر متصل تقویت‌شده برای وزن‌های بالا و سفتی کامل.",
  },
  {
    id: "Trust", fa: "تراست", en: "Trust", core: "bonnell",
    startPrice: 32_000_000, firm: 4, support: 5, motion: 2, cooling: 3, ortho: 3,
    idealMin: 60, idealMax: 120, warranty: 7,
    positions: ["back", "combo"],
    blurb: "حمایت کامل ستون فقرات با دوام بالا در زیرساخت بونل.",
  },
  /* ---------- فنر منفصل ---------- */
  {
    id: "Eldorado", fa: "الدورادو سوپرلوکس", en: "Eldorado", core: "pocket",
    startPrice: 282_000_000, firm: 3, support: 5, motion: 5, cooling: 3, ortho: 4,
    idealMin: 40, idealMax: 130, warranty: 10, badge: "پرچمدار لوکس",
    positions: ["side", "back", "combo"],
    blurb: "سوپرلوکس هیگر؛ ایزولاسیون کامل حرکت و روکش هتلی پنج‌ستاره.",
  },
  {
    id: "Amsterdam", fa: "آمستردام", en: "Amsterdam", core: "pocket",
    startPrice: 70_000_000, firm: 3, support: 4, motion: 5, cooling: 4, ortho: 2,
    idealMin: 40, idealMax: 120, warranty: 10,
    positions: ["side", "back", "combo"],
    blurb: "فنر منفصل اروپایی با تهویه عالی و حس هتلینگ.",
  },
  {
    id: "Avatar", fa: "آواتار", en: "Avatar", core: "pocket",
    startPrice: 65_000_000, firm: 2, support: 4, motion: 5, cooling: 4, ortho: 2,
    idealMin: 35, idealMax: 105, warranty: 10,
    positions: ["side", "combo"],
    blurb: "نرم‌تر از آمستردام؛ ایده‌آل پهلوخواب‌ها و بدن‌های سبک.",
  },
  {
    id: "Zaster", fa: "زستر", en: "Zaster", core: "pocket",
    startPrice: 83_000_000, firm: 3, support: 5, motion: 5, cooling: 4, ortho: 3,
    idealMin: 50, idealMax: 125, warranty: 10,
    positions: ["back", "side", "combo"],
    blurb: "فنر منفصل با پشتیبانی ارتوپدیک؛ تعادل کامل لوکس و طبی.",
  },
  /* ---------- ریباند ---------- */
  {
    id: "Rhino", fa: "راینو", en: "Rhino", core: "rebond",
    startPrice: 54_000_000, firm: 5, support: 5, motion: 5, cooling: 3, ortho: 5,
    idealMin: 70, idealMax: 160, warranty: 10, badge: "طبی ارتوپدیک",
    positions: ["back", "stomach"],
    blurb: "ریباند چگالی ۷۰ با سفتی کامل؛ انتخاب جراحان و کلینیک‌ها.",
  },
  {
    id: "Romance", fa: "رومانس", en: "Romance", core: "rebond",
    startPrice: 57_000_000, firm: 4, support: 5, motion: 5, cooling: 3, ortho: 5,
    idealMin: 55, idealMax: 140, warranty: 10, badge: "طبی لوکس",
    positions: ["back", "combo", "side"],
    blurb: "ریباند + لایه آسایش؛ حمایت کمر با حس کمی نرم‌تر.",
  },
  {
    id: "Climax", fa: "کلایمکس", en: "Climax", core: "rebond",
    startPrice: 54_000_000, firm: 4, support: 4, motion: 5, cooling: 3, ortho: 4,
    idealMin: 55, idealMax: 130, warranty: 8,
    positions: ["back", "side"],
    blurb: "بدون فنر، بی‌صدا و یکدست؛ آرامش کامل برای دیسک‌های حساس.",
  },
  {
    id: "Hippo", fa: "هیپو", en: "Hippo", core: "rebond",
    startPrice: 57_000_000, firm: 4, support: 4, motion: 5, cooling: 3, ortho: 4,
    idealMin: 50, idealMax: 125, warranty: 8,
    positions: ["back", "side", "combo"],
    blurb: "ریباند متعادل برای کل خانواده؛ سفتی علمی و کنترل‌شده.",
  },
  /* ---------- فوم سنگین ---------- */
  {
    id: "Knight", fa: "نایت", en: "Knight", core: "foam",
    startPrice: 14_600_000, firm: 4, support: 4, motion: 5, cooling: 2, ortho: 3,
    idealMin: 45, idealMax: 110, warranty: 5,
    positions: ["back", "stomach", "combo"],
    blurb: "فوم سنگین اقتصادی؛ سبک، بی‌صدا و مناسب آپارتمان.",
  },
  {
    id: "Queen", fa: "کوئین", en: "Queen", core: "foam",
    startPrice: 19_300_000, firm: 3, support: 4, motion: 5, cooling: 3, ortho: 3,
    idealMin: 40, idealMax: 110, warranty: 7, badge: "محبوب‌ترین فوم",
    positions: ["back", "side", "combo"],
    blurb: "تعادل نرمی و حمایت؛ پرفروش‌ترین فوم سنگین هیگر.",
  },
  {
    id: "Queen+", fa: "کوئین پلاس", en: "Queen+", core: "foam",
    startPrice: 28_000_000, firm: 3, support: 4, motion: 5, cooling: 3, ortho: 4,
    idealMin: 40, idealMax: 115, warranty: 8,
    positions: ["side", "back", "combo"],
    blurb: "فوم سنگین + لایه مموری؛ تسکین فشار شانه و لگن.",
  },
  {
    id: "Umea", fa: "اومئا", en: "Umea", core: "foam",
    startPrice: 27_200_000, firm: 2, support: 3, motion: 5, cooling: 4, ortho: 2,
    idealMin: 30, idealMax: 85, warranty: 7,
    positions: ["side", "combo"],
    blurb: "مموری فوم ابری؛ غرق‌شدگی لوکس برای پهلوخواب‌ها.",
  },
  {
    id: "Avina", fa: "آوینا", en: "Avina", core: "foam",
    startPrice: 48_000_000, firm: 3, support: 4, motion: 5, cooling: 4, ortho: 3,
    idealMin: 40, idealMax: 115, warranty: 8,
    positions: ["back", "side", "combo"],
    blurb: "فوم سنگین تهویه‌دار؛ خنک‌تر و سرحال‌تر در تابستان.",
  },
  {
    id: "Helsa", fa: "هلسا", en: "Helsa", core: "foam",
    startPrice: 83_000_000, firm: 3, support: 5, motion: 5, cooling: 4, ortho: 4,
    idealMin: 45, idealMax: 125, warranty: 10, badge: "فوم سنگین پرمیوم",
    positions: ["back", "side", "combo"],
    blurb: "چگالی بالا + مموری ارتوپدیک؛ تجربه هتلینگ قابل‌حمل.",
  },
  {
    id: "Pleasure", fa: "پلژر", en: "Pleasure", core: "foam",
    startPrice: 36_000_000, firm: 2, support: 4, motion: 5, cooling: 4, ortho: 3,
    idealMin: 35, idealMax: 100, warranty: 8,
    positions: ["side", "back"],
    blurb: "نرمی مجلل با حمایت کنترل‌شده؛ خواب روی ابرها.",
  },
  {
    id: "Pleasure+", fa: "پلژر پلاس", en: "Pleasure+", core: "foam",
    startPrice: 48_000_000, firm: 2, support: 4, motion: 5, cooling: 4, ortho: 3,
    idealMin: 35, idealMax: 105, warranty: 8,
    positions: ["side", "combo"],
    blurb: "نسخه تکمیل‌شده پلژر با تهویه و دوام بالاتر.",
  },
];

export const shopSearchUrl = (q: string) =>
  `https://higermattress.ir/?s=${encodeURIComponent(q)}&post_type=product`;

export const STORE = {
  phone: "۰۹۱۱۶۴۰۶۴۸۵",
  phoneRaw: "09116406485",
  telHref: "tel:+989116406485",
  address: "بابل، مازندران — شوروم و دفتر مرکزی هیگر",
  hours: "همه‌روزه ۹ تا ۲۱",
  est: "۱۳۸۷",
};
