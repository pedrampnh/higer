const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** Convert Latin digits to Persian digits */
export function toFa(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

/** Format a number with Persian thousands separators */
export function faNum(n: number): string {
  return toFa(Math.round(n).toLocaleString("en-US"));
}

/** Format تومان price, e.g. 28,000,000 → «۲۸٬۰۰۰٬۰۰۰ تومان» */
export function faPrice(toman: number): string {
  return `${faNum(toman)} تومان`;
}

/** Short price in millions: 282000000 → «۲۸۲ میلیون» */
export function faMillion(toman: number): string {
  return `${faNum(Math.round(toman / 1_000_000))} میلیون`;
}
