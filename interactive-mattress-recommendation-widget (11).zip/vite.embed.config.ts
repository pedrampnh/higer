import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

/* ساخت نسخه قابل‌جاسازی (یک فایل JS مستقل) برای اسنیپت‌های وردپرس:
   npx vite build --config vite.embed.config.ts */
export default defineConfig({
  plugins: [react(), tailwindcss()],
  publicDir: false,
  define: {
    "process.env.NODE_ENV": JSON.stringify("production"),
  },
  build: {
    outDir: "embed-dist",
    emptyOutDir: true,
    target: "es2018",
    minify: true,
    cssCodeSplit: false,
    lib: {
      entry: "src/embed.tsx",
      name: "HigerHome",
      formats: ["iife"],
      fileName: () => "higer-home-app.js",
    },
  },
});
