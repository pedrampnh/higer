/*
 * Builds the WordPress snippets from the SAME React app used by the preview:
 *   public/higer-home.php              PHP snippet, photos embedded
 *   public/higer-home-host-images.php  PHP snippet, photos read from the host
 *   public/higer-home.html             HTML snippet, photos by URL
 * Run after:  npx vite build --config vite.embed.config.ts
 */
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..");
const need = (cond, msg) => { if (!cond) throw new Error(msg); };

/* ---------- 1. app bundle, made safe for inline <script> + ASCII only ---------- */
let js = fs.readFileSync(path.join(root, "embed-dist/higer-home-app.js"), "utf8");
js = js.replace(/<!--/g, "\\x3C!--").replace(/<script/gi, "\\x3Cscript").replace(/<\/script/gi, "<\\/script");
js = Array.from(js).map((ch) => {
  const cp = ch.codePointAt(0);
  if (cp < 128) return ch;
  if (cp < 0x10000) return "\\u" + cp.toString(16).padStart(4, "0");
  const h = cp - 0x10000;
  return "\\u" + (0xd800 + (h >> 10)).toString(16) + "\\u" + (0xdc00 + (h & 0x3ff)).toString(16);
}).join("");
need(/^[\x00-\x7F]*$/.test(js), "bundle still has non-ASCII");
need(!/<\/script|<!--|<script/i.test(js), "bundle has HTML-sensitive sequence");
need(!/^HIGER_HOME_APP\b/m.test(js), "nowdoc marker collision");

const template = (hostAttrs, assetsExpr) =>
  `<div class="higer-home-host" data-higer-home${hostAttrs} style="display:block;min-height:640px;background:#faf7ef"></div>\n` +
  `<script>window.HIGER_ASSETS=${assetsExpr};</script>\n` +
  `<script>${js}</script>\n`;

/* ---------- 2. HTML snippet ---------- */
const HOST = "https://higermattress.ir/wp-content/uploads/higer-home/";
const htmlSnippet =
  "<!-- Higer home page (same as the preview). Paste into WPCode (HTML Snippet) or an Elementor HTML widget.\n" +
  "     Photos: upload higer-hero.webp, higer-factory.webp and higer-topper.webp to wp-content/uploads/higer-home/\n" +
  "     or replace the three URLs in window.HIGER_ASSETS below.\n" +
  "     Options on the first div: data-header=\"yes\" shows the page's own header, data-footer=\"no\" hides its footer,\n" +
  "     data-fullwidth=\"no\" keeps it inside the column, data-only=\"finder\" shows only the mattress finder. -->\n" +
  template(
    ' data-header="no" data-footer="yes" data-fullwidth="yes" data-only=""',
    JSON.stringify({ hero: HOST + "higer-hero.webp", factory: HOST + "higer-factory.webp", topper: HOST + "higer-topper.webp" }).replace(/\//g, "\\/"),
  );
fs.writeFileSync(path.join(root, "public/higer-home.html"), htmlSnippet, "ascii");
console.log("higer-home.html", Math.round(htmlSnippet.length / 1024) + "KB");

/* ---------- 3. PHP snippets ---------- */
const phpBody = template(
  ' data-header="{HIGER_HEADER}" data-footer="{HIGER_FOOTER}" data-fullwidth="{HIGER_FULLWIDTH}" data-only="{HIGER_ONLY}"',
  "{HIGER_ASSETS_JSON}",
);
const b64Literal = (file) => {
  const s = fs.readFileSync(path.join(root, file)).toString("base64");
  const parts = [];
  for (let i = 0; i < s.length; i += 1000) parts.push(s.slice(i, i + 1000));
  return "'data:image/webp;base64,' .\n" + parts.map((p, i) => "\t\t\t'" + p + "'" + (i < parts.length - 1 ? " ." : ";")).join("\n");
};

const HEAD = (edition) => `<?php
/**
 * Higer Home - full home page, identical to the preview (React app in an isolated Shadow DOM).
 * ${edition}
 *
 * WPCode setup:
 *   1. Code Type: PHP Snippet.
 *   2. Insert Method: Shortcode  -> Save -> Activate.
 *   3. Copy the shortcode WPCode shows in the sidebar and place it on the home page
 *      (Gutenberg "Shortcode" block or Elementor "Shortcode" widget, full-width section).
 *
 * The [higer_home] shortcode is also registered and accepts options:
 *   [higer_home header="yes"]      also show the page's own header (off by default: the theme has one)
 *   [higer_home footer="no"]       hide the page's own footer
 *   [higer_home fullwidth="no"]    stay inside the column instead of spanning the screen
 *   [higer_home only="finder"]     show only the mattress finder (Tashik-Sanj)
 *
 * Activate only ONE Higer Home snippet on the site.
 */

defined( 'ABSPATH' ) || exit;
`;

const RENDER = (assetsCode) => `
if ( ! function_exists( 'higer_home_html' ) ) {
	/**
	 * Returns the home page markup.
	 *
	 * @param array|string $atts Shortcode attributes.
	 * @return string
	 */
	function higer_home_html( $atts = array() ) {
		$defaults = array(
			'header'    => 'no',
			'footer'    => 'yes',
			'fullwidth' => 'yes',
			'only'      => '',
		);
		$atts = is_array( $atts ) ? array_merge( $defaults, array_change_key_case( $atts, CASE_LOWER ) ) : $defaults;
		foreach ( array( 'header', 'footer', 'fullwidth' ) as $key ) {
			$atts[ $key ] = in_array( strtolower( (string) $atts[ $key ] ), array( 'no', '0', 'false', 'off' ), true ) ? 'no' : 'yes';
		}
		$atts['only'] = ( 'finder' === strtolower( (string) $atts['only'] ) ) ? 'finder' : '';

${assetsCode}

		$json = function_exists( 'wp_json_encode' ) ? wp_json_encode( $assets ) : json_encode( $assets );

		$html = <<<'HIGER_HOME_APP'
${phpBody}HIGER_HOME_APP;

		return str_replace(
			array( '{HIGER_HEADER}', '{HIGER_FOOTER}', '{HIGER_FULLWIDTH}', '{HIGER_ONLY}', '{HIGER_ASSETS_JSON}' ),
			array( $atts['header'], $atts['footer'], $atts['fullwidth'], $atts['only'], $json ),
			$html
		);
	}
}

if ( ! shortcode_exists( 'higer_home' ) ) {
	add_shortcode( 'higer_home', 'higer_home_html' );
}

/*
 * When WPCode runs this snippet as its own shortcode, print the page right here.
 * In any other mode (auto-insert) nothing is printed, so the rest of the site stays clean.
 */
$higer_in_shortcode = false;
foreach ( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 30 ) as $higer_frame ) {
	if ( ! empty( $higer_frame['function'] ) && 0 === strpos( $higer_frame['function'], 'do_shortcode' ) ) {
		$higer_in_shortcode = true;
		break;
	}
}
if ( $higer_in_shortcode ) {
	echo higer_home_html();
}
`;

const EMBEDDED_ASSETS = `		$assets = array(
			'hero'    => ${b64Literal("public/images/hero-bg-mini.webp").replace(/;$/, "")},
			'factory' => ${b64Literal("public/images/factory-mini.webp").replace(/;$/, "")},
			'topper'  => ${b64Literal("public/images/topper-mini.webp").replace(/;$/, "")},
		);
		// Optional: define( 'HIGER_HOME_HERO_IMAGE', 'https://...' ) etc. in wp-config.php to use your own photos.
		foreach ( array( 'hero' => 'HIGER_HOME_HERO_IMAGE', 'factory' => 'HIGER_HOME_FACTORY_IMAGE', 'topper' => 'HIGER_HOME_TOPPER_IMAGE' ) as $key => $constant ) {
			if ( defined( $constant ) && '' !== trim( (string) constant( $constant ) ) ) {
				$assets[ $key ] = function_exists( 'esc_url_raw' ) ? esc_url_raw( constant( $constant ) ) : constant( $constant );
			}
		}`;

const HOST_SETTINGS = `
/*
 * =========================== PHOTO SETTINGS ===========================
 * Nothing has to be edited here. Each photo is found in this order:
 * 1. A file uploaded to WordPress Media (Media > Add New) named
 *      higer-hero.webp     -> background photo of the top section
 *      higer-factory.webp  -> photo of the "Why Higer" section
 *      higer-topper.webp   -> photo of the topper & protector section
 *    (.jpg, .jpeg or .png work too. To use your own photo just give it one
 *     of these names before uploading.)
 * 2. A file with the same names in this folder on the host:
 *      wp-content/uploads/higer-home/
 * 3. A URL pasted between the quotes below (overrides 1 and 2).
 * A missing photo is replaced by a navy brand background.
 * ======================================================================
 */
if ( ! defined( 'HIGER_HOME_HERO_IMAGE' ) ) {
	define( 'HIGER_HOME_HERO_IMAGE', '' ); // optional: full URL of the top background photo
}
if ( ! defined( 'HIGER_HOME_FACTORY_IMAGE' ) ) {
	define( 'HIGER_HOME_FACTORY_IMAGE', '' ); // optional: full URL of the "Why Higer" photo
}
if ( ! defined( 'HIGER_HOME_TOPPER_IMAGE' ) ) {
	define( 'HIGER_HOME_TOPPER_IMAGE', '' ); // optional: full URL of the topper & protector photo
}

if ( ! function_exists( 'higer_home_image' ) ) {
	/**
	 * Finds a photo on this host. Returns its URL, or an empty string.
	 *
	 * @param string $name   Base file name without extension, e.g. "higer-hero".
	 * @param string $custom URL from the settings above.
	 * @return string
	 */
	function higer_home_image( $name, $custom = '' ) {
		$custom = trim( (string) $custom );
		if ( '' !== $custom ) {
			if ( preg_match( '/attachment_id=(\\d+)/', $custom, $matches ) && function_exists( 'wp_get_attachment_image_url' ) ) {
				$attachment_url = wp_get_attachment_image_url( (int) $matches[1], 'large' );
				if ( $attachment_url ) {
					return $attachment_url;
				}
			}
			return $custom;
		}
		static $found = array();
		if ( isset( $found[ $name ] ) ) {
			return $found[ $name ];
		}
		$found[ $name ] = '';
		$extensions     = 'jpg|jpeg|png|webp';

		// 1) Media library upload.
		global $wpdb;
		if ( isset( $wpdb ) && function_exists( 'wp_get_attachment_image_url' ) && function_exists( 'get_post' ) ) {
			$safe_name = preg_replace( '/[^a-z0-9-]/', '', $name );
			$pattern   = '^(.*/)?' . $safe_name . '(-[0-9]+)?(-scaled)?[-.](' . $extensions . ')$';
			$ids       = $wpdb->get_col( $wpdb->prepare( 'SELECT post_id FROM ' . $wpdb->postmeta . " WHERE meta_key = '_wp_attached_file' AND meta_value REGEXP %s ORDER BY post_id DESC LIMIT 3", $pattern ) );
			if ( is_array( $ids ) ) {
				foreach ( $ids as $id ) {
					$attachment = get_post( $id );
					if ( ! $attachment || 'trash' === $attachment->post_status ) {
						continue;
					}
					$attachment_url = wp_get_attachment_image_url( (int) $id, 'full' );
					if ( $attachment_url ) {
						$found[ $name ] = $attachment_url;
						break;
					}
				}
			}
		}

		// 2) File uploaded through the hosting file manager.
		if ( '' === $found[ $name ] && function_exists( 'wp_upload_dir' ) ) {
			$uploads = wp_upload_dir( null, false );
			if ( ! empty( $uploads['basedir'] ) && ! empty( $uploads['baseurl'] ) ) {
				$base_dir = rtrim( $uploads['basedir'], '/' ) . '/higer-home/';
				$base_url = rtrim( $uploads['baseurl'], '/' ) . '/higer-home/';
				foreach ( explode( '|', $extensions ) as $ext ) {
					if ( file_exists( $base_dir . $name . '.' . $ext ) ) {
						$found[ $name ] = $base_url . $name . '.' . $ext;
						break;
					}
				}
			}
		}
		return $found[ $name ];
	}
}
`;

const HOST_ASSETS = `		$assets = array(
			'hero'    => higer_home_image( 'higer-hero', HIGER_HOME_HERO_IMAGE ),
			'factory' => higer_home_image( 'higer-factory', HIGER_HOME_FACTORY_IMAGE ),
			'topper'  => higer_home_image( 'higer-topper', HIGER_HOME_TOPPER_IMAGE ),
		);
		if ( function_exists( 'esc_url_raw' ) ) {
			foreach ( $assets as $key => $url ) {
				if ( '' !== $url ) {
					$assets[ $key ] = esc_url_raw( $url );
				}
			}
		}`;

const writePhp = (file, php) => {
  need(/^[\x00-\x7F]*$/.test(php), "non-ASCII in " + file);
  fs.writeFileSync(path.join(root, "public", file), php, "ascii");
  let note = "(php-parser not installed, syntax not checked)";
  try {
    const PP = require("php-parser");
    const Engine = PP.Engine || PP;
    new Engine({ parser: { php7: true, extractDoc: false }, ast: { withPositions: false } }).parseCode(php, file);
    note = "PHP SYNTAX OK";
  } catch (e) {
    if (String(e.message).startsWith("Parse Error")) throw e;
  }
  console.log(file, Math.round(php.length / 1024) + "KB", note);
};

writePhp("higer-home.php", HEAD("EMBEDDED PHOTOS edition: nothing else has to be uploaded.") + RENDER(EMBEDDED_ASSETS));
writePhp("higer-home-host-images.php", HEAD("HOST PHOTOS edition: the photos are loaded from your own hosting.") + HOST_SETTINGS + RENDER(HOST_ASSETS));
